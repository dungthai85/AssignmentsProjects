/*
 * TCSS 305 - Winter 2019
 * Assignment 3 - Road Rage
 */

package model;

import java.util.Map;

/**
* Vehicle sub-class called Atv that implements
* the Vehicle interface.
* @author Dung Thai
* @version 8 Feb 2019
*/
public class Atv extends AbstractVehicle {
    
    /** The death time number during a collision.
     */
    private static final int DEATH_TIME = 25;

    /**
     * The constructor for the Atv class.
     * It calls the superclass constructor with arguments.
     * @param theX The X coordinate of the vehicle
     * @param theY The Y coordinate of the vehicle
     * @param theDir The direction the vehicle is facing.
     */
    public Atv(final int theX, final int theY, final Direction theDir) {
        super(theX, theY, theDir, DEATH_TIME);
    }

    /**
     * Returns the direction this vehicle would like to move, based on the given
     * map of the neighboring terrain.
     * Atv randomly selects to go straight, left, or right.
     * Never reverses.
     * 
     * @param theNeighbors The map of neighboring terrain.
     * @return Vehicles next direction to move
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {

        return randomDir(theNeighbors);
    }
    
    /**
     * Returns if this object may move onto the given type of
     * terrain except WALL.
     * 
     * @param theTerrain The terrain.
     * @param theLight The light color.
     * @return False if Terrain is a wall.
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {
        
        return theTerrain != Terrain.WALL;
    }
}
