/*
 * TCSS 305 - Winter 2019
 * Assignment 3 - Road Rage
 */

package model;

import java.util.Map;

/**
* Vehicle sub-class called Taxi that implements
* the Vehicle interface.
* @author Dung Thai
* @version 8 Feb 2019
*/
public class Taxi extends AbstractVehicle {
    
    /** The death time number during a collision.
     */
    private static final int DEATH_TIME = 15;
    
    /** The default count for red light at crosswalks.
     */
    private static final int MY_RED_DEFAULT = 3;
    
    /** The count till Taxi can move.
     */
    private int myRedCount;

    /**
     * The constructor for the Taxi class.
     * It calls the superclass constructor with arguments.
     * @param theX The X coordinate of the vehicle
     * @param theY The Y coordinate of the vehicle
     * @param theDir The direction the vehicle is facing.
     */
    public Taxi(final int theX, final int theY, final Direction theDir) {
        super(theX, theY, theDir, DEATH_TIME);    

        myRedCount = MY_RED_DEFAULT;
    }
    
    /**
     * Returns the direction this vehicle would like to move, based on the given
     * map of the neighboring terrain.
     * The Taxi prefers to go straight, if it is not possible it will go left,
     * if that isn't possible it will go right.
     * If no direction is valid it will reverse.
     * 
     * @param theNeighbors The map of neighboring terrain.
     * @return Vehicles next direction to move
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {
        Direction nextTurn = getDirection().reverse();
        if (isDrivableTerrain(theNeighbors.get(getDirection()))) {
            nextTurn = getDirection();
        } else if (isDrivableTerrain(theNeighbors.get(getDirection().left()))) {
            nextTurn = getDirection().left();
        } else if (isDrivableTerrain(theNeighbors.get(getDirection().right()))) {
            nextTurn = getDirection().right();
        }
        return nextTurn;
    }
    
    /**
     * Returns if this object may move onto the given type of
     * terrain, when the street lights are the given color.
     * The Taxi will stop at a red CROSSWALK for 3 seconds.
     * then it will continue to move.
     * 
     * @param theTerrain The terrain.
     * @param theLight The light color.
     * @return False if Terrain is WALL, TRAIL, GRASS, or red Lights
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {
        boolean pass = true;
        if (theTerrain == Terrain.WALL || theTerrain == Terrain.TRAIL 
                        || theTerrain == Terrain.GRASS  
                        || (theTerrain == Terrain.LIGHT && theLight == Light.RED)) {
            pass = false;
        }
        if (theTerrain == Terrain.CROSSWALK && theLight == Light.RED) {
            pass = false;
            if (myRedCount == 0) {
                myRedCount = MY_RED_DEFAULT;
                pass = true;
            }
            myRedCount--;
        }
        return pass;
    }
}
