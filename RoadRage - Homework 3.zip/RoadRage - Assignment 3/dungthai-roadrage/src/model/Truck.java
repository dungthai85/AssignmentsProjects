/*
 * TCSS 305 - Winter 2019
 * Assignment 3 - Road Rage
 */

package model;

import java.util.Map;

 /**
 * Vehicle sub-class called Truck that implements
 * the Vehicle interface.
 * @author Dung Thai
 * @version 8 Feb 2019
 */
public class Truck extends AbstractVehicle {
    
    /** The death time number during a collision.
     */
    private static final int DEATH_TIME = 0;

    /**
     * The constructor for the Truck class.
     * It calls the superclass constructor with arguments.
     * @param theX The X coordinate of the vehicle
     * @param theY The Y coordinate of the vehicle
     * @param theDir The direction the vehicle is facing.
     */
    public Truck(final int theX, final int theY, final Direction theDir) {
        super(theX, theY, theDir, DEATH_TIME);

    }
    
    /**
     * Returns the direction this vehicle would like to move, based on the given
     * map of the neighboring terrain.
     * The Truck randonly move straight, left, or right.
     * If theres no other moves it will reverse.
     * 
     * @param theNeighbors The map of neighboring terrain.
     * @return Vehicles next direction to move
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {
        Direction nextTurn = getDirection().reverse();
        if (isDrivableTerrain(theNeighbors.get(getDirection()))
                        || isDrivableTerrain(theNeighbors.get(getDirection().left()))
                        || isDrivableTerrain(theNeighbors.get(getDirection().right()))) {
            nextTurn = randomDir(theNeighbors);
        }
        return nextTurn;
    }
    
    /**
     * Returns if this object may move onto the given type of
     * terrain, when the street lights are the given color.
     * 
     * @param theTerrain The terrain.
     * @param theLight The light color.
     * @return True if CROSSWALK is YELLOW or GREEN, is on STREET, or any LIGHT.
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {

        return (theTerrain == Terrain.CROSSWALK && theLight == Light.YELLOW)
                        || (theTerrain == Terrain.CROSSWALK && theLight == Light.GREEN)
                        || theTerrain == Terrain.STREET || theTerrain == Terrain.LIGHT;
    }
}
