/*
 * TCSS 305 - Winter 2019
 * Assignment 3 - Road Rage
 */

package model;

import java.util.Map;

/**
* Vehicle sub-class called Bicycle that implements
* the Vehicle interface.
* @author Dung Thai
* @version 8 Feb 2019
*/
public class Bicycle extends AbstractVehicle {

    /** The death time number during a collision.
     */
    private static final int DEATH_TIME = 35;

    /**
     * The constructor for the Bicycle class.
     * It calls the superclass constructor with arguments.
     * @param theX The X coordinate of the vehicle
     * @param theY The Y coordinate of the vehicle
     * @param theDir The direction the vehicle is facing.
     */
    public Bicycle(final int theX, final int theY, final Direction theDir) {
        super(theX, theY, theDir, DEATH_TIME);
    }
    
    /**
     * Returns the direction this vehicle would like to move, based on the given
     * map of the neighboring terrain.
     * It will go on TRAIL if TRAIL is available.
     * if there is no TRAIL, it will go straight, if thats not valid,
     * it will go left, if thats not valid it will go right.
     * If no moves are valid it will reverse.
     * 
     * @param theNeighbors The map of neighboring terrain.
     * @return Vehicles next direction to move
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {
        Direction nextTurn = getDirection().reverse();
        if (theNeighbors.get(getDirection()) == Terrain.TRAIL) {
            nextTurn = getDirection();
        } else if (theNeighbors.get(getDirection().left()) == Terrain.TRAIL) {
            nextTurn = getDirection().left();
        } else if (theNeighbors.get(getDirection().right()) == Terrain.TRAIL) {
            nextTurn =  getDirection().right();
        } else if (isDrivableTerrain(theNeighbors.get(getDirection()))) {
            nextTurn = getDirection();
        } else if (isDrivableTerrain(theNeighbors.get(getDirection().left()))) {
            nextTurn = getDirection().left();
        } else if (isDrivableTerrain(theNeighbors.get(getDirection().right()))) {
            nextTurn = getDirection().right();
        }
        return nextTurn;
    }
    
    /**
     * Returns if this object may move onto the given type of
     * terrain, when the street lights are the given color.
     * 
     * @param theTerrain The terrain.
     * @param theLight The light color.
     * @return True Terrain is TRAIL, STREET, CROSSWALK is GREEN or LIGHT is GREEN.
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {
        
        return theTerrain == Terrain.TRAIL || theTerrain == Terrain.STREET 
                        || (theTerrain == Terrain.CROSSWALK && theLight == Light.GREEN) 
                        || (theTerrain == Terrain.LIGHT && theLight == Light.GREEN);
    }
    
}