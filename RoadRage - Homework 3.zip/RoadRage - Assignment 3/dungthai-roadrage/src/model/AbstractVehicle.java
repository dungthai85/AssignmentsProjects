/*
 * TCSS 305 - Winter 2019
 * Assignment 3 - Road Rage
 */

package model;

import java.util.Map;

/**
 * Parent Class for the subclasses that implements the Vehicle interface.
 * @author Dung Thai
 * @version 8 Feb 2019
 *
 */
public abstract class AbstractVehicle implements Vehicle {
    
    // Instance fields
    
    /** The X Coordinate of this vehicle.
     */
    private int myX;
    
    /** The Y Coordinate of this vehicle.
     */
    private int myY;
    
    /** The direction this vehicle is facing.
     */
    private Direction myDir;
    
    /** The Default X Coordinate of this vehicle.
     */
    private final int myDefaultX;
    
    /** The Default Y Coordinate of this vehicle.
     */
    private final int myDefaultY;
    
    /** The Default direction this vehicle is facing.
     */
    private final Direction myDefaultDir;
    
    /** The Death time of the Vehicle.
     */
    private final int myDeathTime;
    
    /** Value if the car is alive or dead.
     */
    private boolean myAlive = true;
    
    /** The poke count of the car till it comes back alive.
     */
    private int myPokeCount;

    /**
     * Constructor for AbstractVehicle that sends arguments to vehicle class when called.
     * This is where Instance variables get initialized.
     * @param theX the X coordinate of the vehicle.
     * @param theY the Y coordinate of the vehicle.
     * @param theDir the direction the vehicle is facing.
     * @param theDeath the Death count from vehicles.
     */
    public AbstractVehicle(final int theX, final int theY, final Direction theDir,
                           final int theDeath) {
        super();
        myX = theX;
        myY = theY;
        myDir = theDir;
        myDefaultX = theX;
        myDefaultY = theY;
        myDefaultDir = theDir;
        myDeathTime = theDeath;
        myPokeCount = theDeath;
    }
    
    /**
     * Notifies when vehicle has collided with another vehicle.
     * Lower DeathTime means the vehicle is stronger and will stay alive.
     * Also checks if you're dead, you stay dead.
     */
    @Override
    public void collide(final Vehicle theOther) {
        if (getDeathTime() > theOther.getDeathTime() && isAlive() && theOther.isAlive()) {
            myAlive = false;
        } 
        if (!isAlive() && theOther.isAlive()) {
            myAlive = false;
        } 
    }

    /**
     * Gets the Death time until it should be revived.
     */
    @Override
    public int getDeathTime() {
        
        return myDeathTime;
    }

    /**
     * Returns the image file for the GUI to draw the vehicle.
     */
    @Override
    public String getImageFileName() {
        final String vehicle = getClass().getSimpleName().toLowerCase();
        if (!isAlive()) {
            return vehicle + "_dead.gif";
        }
        return vehicle + ".gif";
    }

    /**
     * Returns the direction this vehicle is facing.
     */
    @Override
    public Direction getDirection() {
        
        return myDir;
    }

    /**
     * Returns the X coordinate of this vehicle.
     */
    @Override
    public int getX() {
      
        return myX;
    }

    /**
     * Returns the X coordinate of this vehicle.
     */
    @Override
    public int getY() {
       
        return myY;
    }
    
    /**
     * Returns if the car is alive or dead.
     */
    @Override
    public boolean isAlive() {
  
        return myAlive;
    }

    /**
     * This method keeps track of the moves left until vehicle is revived.
     */
    @Override
    public void poke() {
        if (!isAlive()) {
            if (myPokeCount == 0) {
                myAlive = true;
                setDirection(Direction.random());
                myPokeCount = myDeathTime;
            }
            myPokeCount--;
        }
        
    }

    /**
     * Sets all values back to Initial default values.
     */
    @Override
    public void reset() {
        myX = myDefaultX;
        myY = myDefaultY;
        myDir = myDefaultDir;
        myAlive = true;
    }

    /**
     * Sets the movement of this vehicle.
     */
    @Override
    public void setDirection(final Direction theDir) {
        myDir = theDir;
        
    }

    /**
     * Sets the X coordinate of this vehicle.
     */
    @Override
    public void setX(final int theX) {
        myX = theX;
        
    }

    /**
     * Sets the Y coordinate of this vehicle.
     */
    @Override
    public void setY(final int theY) {
        myY = theY;
        
    }
    
    /**
     * This is a helper method that is to be shared by 
     * Car, Taxi, Truck, and Bicycle subclass.
     * @param theTerrain Takes in Terrain from chooseDirection.
     * @return True if Terrain is STREET, LIGHT OR CROSSWALK.
     */
    protected boolean isDrivableTerrain(final Terrain theTerrain) {
        
        return theTerrain == Terrain.STREET || theTerrain == Terrain.LIGHT 
                        || theTerrain == Terrain.CROSSWALK;
    }

    /**
     * Random direction chooser shared by subclasses.
     * Uses the random from Direction.
     * If reverse is chosen or that direction is not valid, 
     * it loops and recalls again until that direction is valid,
     * then saves the direction. 
     * @param theNeighbors the map location from chooseDirection.
     * @return Random direction when called.
     */
    protected Direction randomDir(final Map<Direction, Terrain> theNeighbors) {
        Direction random = Direction.random();
        while (getDirection().reverse() == random 
                        || !canPass(theNeighbors.get(random), Light.GREEN)) {
            random = Direction.random();      
        }
        return random;
    }

}