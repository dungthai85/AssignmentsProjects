/*
 * TCSS 305 - Winter 2019
 * Assignment 3 - Road Rage
 */

package model;

import java.util.Map;

/**
* Vehicle sub-class called Human that implements
* the Vehicle interface.
* @author Dung Thai
* @version 8 Feb 2019
*/
public class Human extends AbstractVehicle {

    /** The death time number during a collision.
     */
    private static final int DEATH_TIME = 45;

    /**
     * The constructor for the Human class.
     * It calls the superclass constructor with arguments.
     * @param theX The X coordinate of the vehicle
     * @param theY The Y coordinate of the vehicle
     * @param theDir The direction the vehicle is facing.
     */
    public Human(final int theX, final int theY, final Direction theDir) {
        super(theX, theY, theDir, DEATH_TIME);
    }
    
     /**
     * Helper method to check if Terrain is GRASS or CROSSWALK.
     * @param theTerrain takes in the Terrain from chooseDirection.
     * @return True if terrain is GRASS or CROSSWALK.
     */
    private static boolean isMovable(final Terrain theTerrain) {

        return theTerrain == Terrain.GRASS || theTerrain == Terrain.CROSSWALK;
    }
    
    /**
     * Returns the direction this vehicle would like to move, based on the given
     * map of the neighboring terrain.
     * If human sees a CROSSWALK, it will go that direction.
     * If it is just GRASS, it will go in random directions.
     * if there's no valid moves it will reverse.
     * 
     * @param theNeighbors The map of neighboring terrain.
     * @return Vehicles next direction to move
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {
        Direction nextTurn = getDirection().reverse();
        if (isMovable(theNeighbors.get(getDirection())) 
                      || isMovable(theNeighbors.get(getDirection().left())) 
                      || isMovable(theNeighbors.get(getDirection().right()))) {
            if (theNeighbors.get(getDirection()) == Terrain.CROSSWALK) {
                nextTurn = getDirection();
            } else if (theNeighbors.get(getDirection().left()) == Terrain.CROSSWALK) {
                nextTurn = getDirection().left();
            } else if (theNeighbors.get(getDirection().right()) == Terrain.CROSSWALK) {
                return getDirection().right();
            } else { 
                nextTurn = randomDir(theNeighbors);
            }
        }
        return nextTurn;
    }
    
    /**
     * Returns if this object may move onto the given type of
     * terrain, when the street lights are the given color.
     * 
     * @param theTerrain The terrain.
     * @param theLight The light color.
     * @return True if Terrain is GRASS, CROSSWALK is RED or CROSSWALK is YELLOW.
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {

        return theTerrain == Terrain.GRASS || (theTerrain == Terrain.CROSSWALK 
                        && theLight == Light.YELLOW) || (theTerrain == Terrain.CROSSWALK 
                        && theLight == Light.RED);
    }
}
