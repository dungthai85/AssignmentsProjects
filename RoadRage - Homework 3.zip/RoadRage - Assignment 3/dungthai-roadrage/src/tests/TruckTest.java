/*
 * TCSS 305 - Winter 2019
 * Assignment 3 - Road Rage
 */
package tests;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import model.Direction;
import model.Light;
import model.Terrain;
import model.Truck;
import org.junit.Before;
import org.junit.Test;





/**
 * Unit Tests for Truck class.
 * 
 * @author Dung Thai
 * @version 8 Feb 2019
 */
public class TruckTest {
    
    /** Random number to check for all possible solutions.
     */
    private static final int RANDOM_TRIES = 100;
        
    /** Object of this vehicle.
     */
    private Truck myTruck;

    /**
     * Sets values of Truck to before each method test.
     */
    @Before
    public void setUp() {
        myTruck = new Truck(12, 5, Direction.EAST);
    }

    /**
     * Test method for Truck Constructor.
     * Testing X.
     */
    @Test
    public void testTruckForX() {
        
        assertEquals("Get Truck X Incorrect!", 12, myTruck.getX());
    }
    
    /**
     * Test method for Truck Constructor.
     * Testing Y.
     */
    @Test
    public void testTruckForY() {
        
        assertEquals("Get Truck Y Incorrect!", 5, myTruck.getY());
    }
    
    /**
     * Test method for Truck Constructor.
     * Testing if getDirection.
     */
    @Test
    public void testTruckForDirection() {

        assertEquals("Get Direction is Incorrect!",
                     Direction.EAST, myTruck.getDirection());
    }
    
    /**
     * Test method for Truck Constructor.
     * Testing DeathTime.
     */
    @Test
    public void testTruckForDeath() {

        assertEquals("Get DeathTime Incorrect!", 0, myTruck.getDeathTime());
    }
    
    /**
     * Test method for Truck Constructor.
     * Testing isAlive value.
     */
    @Test
    public void testTruckForAlive() {
        
        assertTrue("Initial isAlive() set wrong!", myTruck.isAlive());
    }
    
    /**
     * Test Setter for Truck Constructor.
     * Testing X.
     */
    @Test
    public void testTruckForSetterX() {
        myTruck.setX(5);
        assertEquals("Get Truck X Incorrect!", 5, myTruck.getX());
    }
    
    /**
     * Test Setter for Truck Constructor.
     * Testing Y.
     */
    @Test
    public void testTruckForSetterY() {
        myTruck.setY(12);
        assertEquals("Get Truck Y Incorrect!", 12, myTruck.getY());
    }
    
    /**
     * Test Setter for Truck Constructor.
     * Testing if setDirection.
     */
    @Test
    public void testTruckForSetDirection() {
        myTruck.setDirection(Direction.WEST);
        assertEquals("Get Direction is Incorrect!",
                     Direction.WEST, myTruck.getDirection());
    }
    

    /**
     * Test method for chooseDirection.
     * Checks getDirection().
     * If Straight, left, right, and back is STREET.
     */
    @Test
    public void testChooseDirectionStreet() {
        final Map<Direction, Terrain> neighbors = new HashMap<Direction, Terrain>();
        neighbors.put(Direction.WEST, Terrain.STREET);
        neighbors.put(Direction.NORTH, Terrain.STREET);
        neighbors.put(Direction.EAST, Terrain.STREET);
        neighbors.put(Direction.SOUTH, Terrain.STREET);
        
        boolean seenWest = false;
        boolean seenNorth = false;
        boolean seenEast = false;
        boolean seenSouth = false;
        
        final Truck truck = new Truck(0, 0, Direction.NORTH);
        
        for (int count = 0; count < RANDOM_TRIES; count++) {
            final Direction d = truck.chooseDirection(neighbors);
            
            if (d == Direction.WEST) {
                seenWest = true;
            } else if (d == Direction.NORTH) {
                seenNorth = true;
            } else if (d == Direction.EAST) {
                seenEast = true;
            } else if (d == Direction.SOUTH) { // Should not pick reverse.
                seenSouth = true;
            }
        }
 
        assertTrue("Truck chooseDirection() failed to select randomly "
                   + "among all possible valid choices!",
                   seenWest && seenNorth && seenEast);
            
        assertFalse("Truck chooseDirection() no need to reverse!",
                    seenSouth);
    }
    
    /**
     * Test method for chooseDirection.
     * Gets getDirection().right().
     * If Straight is a WALL, left is a WALL, right is LIGHT, and back is LIGHT.
     */
    @Test
    public void testChooseDirectionLight() {
        final Map<Direction, Terrain> neighbors = new HashMap<Direction, Terrain>();
        neighbors.put(Direction.WEST, Terrain.WALL);
        neighbors.put(Direction.NORTH, Terrain.WALL);
        neighbors.put(Direction.EAST, Terrain.LIGHT);
        neighbors.put(Direction.SOUTH, Terrain.LIGHT);
        
        boolean seenWest = true;
        boolean seenNorth = true;
        boolean seenEast = false;
        boolean seenSouth = false;
        
        final Truck truck = new Truck(0, 0, Direction.NORTH);
        
        for (int count = 0; count < RANDOM_TRIES; count++) {
            final Direction d = truck.chooseDirection(neighbors);
            
            if (d == Direction.WEST) {
                seenWest = false;
            } else if (d == Direction.NORTH) {
                seenNorth = false;
            } else if (d == Direction.EAST) {
                seenEast = true;
            } else if (d == Direction.SOUTH) { // Should not pick reverse.
                seenSouth = true;
            }
        }
 
        assertTrue("Truck chooseDirection() failed to select randomly "
                   + "among all possible valid choices!",
                   seenWest && seenNorth && seenEast);
            
        assertFalse("Truck chooseDirection() no need to reverse!",
                    seenSouth);
    }
    
    /**
     * Test method for chooseDirection.
     * Checks getDirection().left().
     * If left is CROSSWALK, straight is WALL, right is CROSSWALK, and behind is CROSSWALK.
     */
    @Test
    public void testChooseDirectionCrosswalk() {
        final Map<Direction, Terrain> neighbors = new HashMap<Direction, Terrain>();
        neighbors.put(Direction.WEST, Terrain.CROSSWALK);
        neighbors.put(Direction.NORTH, Terrain.WALL);
        neighbors.put(Direction.EAST, Terrain.CROSSWALK);
        neighbors.put(Direction.SOUTH, Terrain.CROSSWALK);
        
        boolean seenWest = false;
        boolean seenNorth = true;
        boolean seenEast = false;
        boolean seenSouth = false;
        
        final Truck truck = new Truck(0, 0, Direction.NORTH);
        
        for (int count = 0; count < RANDOM_TRIES; count++) {
            final Direction d = truck.chooseDirection(neighbors);
            
            if (d == Direction.WEST) {
                seenWest = true;
            } else if (d == Direction.NORTH) {
                seenNorth = false;
            } else if (d == Direction.EAST) {
                seenEast = true;
            } else if (d == Direction.SOUTH) { // Should not pick reverse.
                seenSouth = true;
            }
        }
 
        assertTrue("Truck chooseDirection() failed to select randomly "
                   + "among all possible valid choices!",
                   seenWest && seenNorth && seenEast);
            
        assertFalse("Truck chooseDirection() no need to reverse!",
                    seenSouth);
    }
    
    /**
     * Test method for ChooseDirection.
     * If no moves valid, select random.
     */
    @Test
    public void testChooseDirectionReverse() {
        for (final Terrain terrain : Terrain.values()) {
            if (terrain != Terrain.STREET && terrain != Terrain.CROSSWALK
                            && terrain != Terrain.LIGHT) {
                
                final Map<Direction, Terrain> neighbors = new HashMap<Direction, Terrain>();
                neighbors.put(Direction.WEST, terrain);
                neighbors.put(Direction.NORTH, terrain);
                neighbors.put(Direction.EAST, terrain);
                neighbors.put(Direction.SOUTH, Terrain.STREET);
                
                final Truck truck = new Truck(0, 0, Direction.NORTH);
               
                assertEquals("Truck chooseDirection() failed "
                                + "when reverse was the only valid choice!",
                             Direction.SOUTH, truck.chooseDirection(neighbors));
            }
                
        }
    }

    /**
     * Trucks travel only on STREET and through LIGHT and CROSSWALK.
     * Trucks stop for CROSSWALK lights that are RED.
     * Test method for {@link model.Truck#canPass(model.Terrain, model.Light)}.
     */
    @Test
    public void testCanPass() {

        final List<Terrain> validTerrain = new ArrayList<>();
        validTerrain.add(Terrain.STREET);
        validTerrain.add(Terrain.LIGHT);
        validTerrain.add(Terrain.CROSSWALK);
        
        final Truck truck = new Truck(0, 0, Direction.NORTH);
        // test each terrain type as next destination
        for (final Terrain nextTerrain : Terrain.values()) {
            // try the test under each light condition
            for (final Light currentLightCondition : Light.values()) {
                if (nextTerrain == Terrain.STREET || nextTerrain == Terrain.LIGHT) {
                
                    // Truck can pass STREET under any light condition
                    assertTrue("Truck should pass street "
                               + ", with light " + currentLightCondition,
                               truck.canPass(nextTerrain, currentLightCondition));
                } else if (nextTerrain == Terrain.CROSSWALK) {
                 
                    // Trucks cannot pass crosswalk if light is RED.
                    if (currentLightCondition == Light.RED) {
                        assertFalse("Truck cannot pass " + nextTerrain
                            + ", with light " + currentLightCondition,
                            truck.canPass(nextTerrain,
                                          currentLightCondition));
                    } else { // If light is GREEN or YELLOW.
                        assertTrue("Truck can pass " + nextTerrain
                            + ", with light " + currentLightCondition,
                            truck.canPass(nextTerrain,
                                          currentLightCondition));
                    }
                } else if (!validTerrain.contains(nextTerrain)) {
 
                    assertFalse("Truck should NOT be able to pass " + nextTerrain
                        + ", with light " + currentLightCondition,
                        truck.canPass(nextTerrain, currentLightCondition));
                }
            } 
        }
    }

}
