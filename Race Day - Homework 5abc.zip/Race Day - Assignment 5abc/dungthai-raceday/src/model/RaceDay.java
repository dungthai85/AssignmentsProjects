/*
 * TCSS 305 - Winter 2019 Assignment 5 - Race Day
 */

package model;


import java.awt.Color;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.Scanner;

/**
 * Race Day Model Communicates with the front-end.
 * 
 * @author Dung Thai
 * @version 9 March 2019
 *
 */
public class RaceDay implements PropertyChangeEnabledRaceControls {

    /**
     * String for the Colon.
     */
    private static final String COLON = ":";

    /**
     * String for the Hashtag.
     */
    private static final String HASH = "#";

    /**
     * String for the false boolean.
     */
    private static final String FALSE = "false";

    /**
     * String for the true boolean.
     */
    private static final String TRUE = "true";

    /** An error message for illegal arguments. 
     */
    private static final String ERROR_MESSAGE = "Race cannot advance beyond amount of time";

    /**
     * Number for leader board array count.
     */
    private static final int LEADERB = 2;

    /**
     * Number for leader board array count.
     */
    private static final int RACERARRAY = 3;

    /**
     * Number for fourth array.
     */
    private static final int TRUEFALSEARRAY = 4;

    /**
     * Number of items for the telemetry and crossing finish line.
     */
    private static final int ARRAYSIZE = 5;

    /**
     * participant number less than 100.
     */
    private static final int MAXID = 100;

    /**
     * Total time for the race in Milliseconds.
     */
    private int myTotalRaceTime;

    /** Stores this objects time.
     */
    private int myTime;

    /**
     * Object for number of racers.
     */
    private String myRacers;

    /**
     * String for Race Name.
     */
    private String myRaceName;

    /**
     * String for Track Geometry.
     */
    private String myTrackGeometry;

    /**
     * Int for Track Width.
     */
    private int myTrackWidth;

    /**
     * Int for Track Height.
     */
    private int myTrackHeight;

    /**
     * Double for Distance of lap.
     */
    private double myLapDistance;

    /** 
     * Race Header Object information gets stored.
     */
    private Header myRaceHeader;

    /** 
     * Participant information gets passed to this object.
     */
    private Participants myRaceParticipants;

    /** 
     * map that stores participants ID and Boolean if they are selected.
     */
    private final Map<Integer, Boolean> myRacerIDandToggle;

    /**
     * The time stamp list wish messages.
     */
    private List<List<Message>> myMessagelist;

    /**
     * Manager for Property Change Listeners. 
     */
    private final PropertyChangeSupport myPCS;


    /**
     * RaceDay Constructor. initiates map time and PCS.
     */
    public RaceDay() {
        myPCS = new PropertyChangeSupport(this);
        myTime = 0;
        myRacerIDandToggle = new HashMap<>();
    }

    /**
     * advances the calls advance 1.
     */
    @Override
    public void advance() {
        if (myTime <= myTotalRaceTime) {
            advance(1);

        }
    }

    /**
     * advances 31 milliseconds.
     */
    @Override
    public void advance(final int theMillisecond) {
        changeTime(myTime + theMillisecond);

    }

    /**
     * sets the value to move to.
     */
    @Override
    public void moveTo(final int theMillisecond) {
        if (myTime > myTotalRaceTime) {
            throw new IllegalArgumentException(ERROR_MESSAGE);
        }
        changeTime(theMillisecond);
    }

    /**
     * Helper method to change the value of time and notify observers. 
     * Functional decomposition. 
     * @param theMillisecond the time to change to
     */
    private void changeTime(final int theMillisecond) {
        final int old = myTime;
        if (theMillisecond >= myMessagelist.size()) {
            myTime = myMessagelist.size() - 1;
        } else {
            myTime = theMillisecond;
        }
        myPCS.firePropertyChange(PROPERTY_TIME, old, myTime);



        if (old < myTime) {
            fireTimeForward(old);
        } else if (old > myTime) {
            fireTimeBackward(old);
        }
    }

    /**
     * Helper method to iterate and send the list forward. 
     * @param theOldTime takes in the old time from the last tick.
     */
    private void fireTimeForward(final int theOldTime) {
        final int old = theOldTime;
        for (int j = old; j <= myTime; j++) {
            for (int i = 0; i < myMessagelist.get(j).size(); i++) {
                if (myMessagelist.get(j).get(i) instanceof TelemetryMessage 
                                && myRacerIDandToggle.get(((TelemetryMessage) myMessagelist.
                                                get(j).get(i)).getRacerID())) {
                    myPCS.firePropertyChange(PROPERTY_MESSAGES, null, 
                                             myMessagelist.get(j).get(i));
                    myPCS.firePropertyChange(PROPERTY_TELEMETRY, null, myMessagelist.get(j));
                } else if (myMessagelist.get(j).get(i) instanceof LineCrossingMessage 
                           && myRacerIDandToggle.get(((LineCrossingMessage) myMessagelist.
                                                get(j).
                                                get(i)).getRacerID())) {
                    myPCS.firePropertyChange(PROPERTY_MESSAGES, null, 
                                             myMessagelist.get(j).get(i));
                } else if (myMessagelist.get(j).get(i) instanceof LeaderboardMessage) {
                    myPCS.firePropertyChange(PROPERTY_MESSAGES, null, 
                                             myMessagelist.get(j).get(i));
                    myPCS.firePropertyChange(PROPERTY_LEADERBOARD, null, 
                                             myMessagelist.get(j).get(i));

                }
            }
        } 
    }

    /**
     * Helper method to iterate and send the list backwards.
     * @param theOldTime the old time before the new tick
     */
    private void fireTimeBackward(final int theOldTime) {
        final int old = theOldTime;
        for (int j = old; j > myTime; j--) {
            for (int i = 0; i < myMessagelist.get(j).size(); i++) {
                if (myMessagelist.get(j).get(i) instanceof TelemetryMessage 
                                && myRacerIDandToggle.get(((TelemetryMessage) myMessagelist.
                                                get(j).get(i)).getRacerID())) {
                    myPCS.firePropertyChange(PROPERTY_MESSAGES, null, 
                                             myMessagelist.get(j).get(i));
                    myPCS.firePropertyChange(PROPERTY_TELEMETRY, null, myMessagelist.get(j));
                } else if (myMessagelist.get(j).get(i) instanceof LineCrossingMessage 
                        && myRacerIDandToggle.get(((LineCrossingMessage) myMessagelist.get(j).
                                                get(i)).getRacerID())) {
                    myPCS.firePropertyChange(PROPERTY_MESSAGES, null, 
                                             myMessagelist.get(j).get(i));
                } else if (myMessagelist.get(j).get(i) instanceof LeaderboardMessage) {
                    myPCS.firePropertyChange(PROPERTY_MESSAGES, null, 
                                             myMessagelist.get(j).get(i));
                    myPCS.firePropertyChange(PROPERTY_LEADERBOARD, null, 
                                             myMessagelist.get(j).get(i));
                } 
            }
        }
    }

    /**
     * toggle participants. takes in ID and toggle value. stores in map.
     */
    @Override
    public void toggleParticipant(final int theParticpantID, final boolean theToggle) {

        myRacerIDandToggle.put(theParticpantID, theToggle);
        myPCS.firePropertyChange(PROPERTY_TOGGLE, null, myRacerIDandToggle);

    }

    /**
     * Helper method to randomly create colors for view.
     */
    private void participantColorSet() {
        final Random r = new Random();
        final Map<Integer, Color> racerIDandColor = new HashMap<>();
        for (int i = 0; i < myRaceParticipants.getNumberOfParticipants(); i++) {
            final Color randomColor = new Color(r.nextFloat(), r.nextFloat(), r.nextFloat());
            racerIDandColor.put(myRaceParticipants.getRacerID(i), randomColor);
        }


        myPCS.firePropertyChange(PROPERTY_COLOR, null, new HashMap<>(racerIDandColor));
    }

    /**
     * load race file sent from gui. checks for valid file. if valid fire property changes.
     */
    @Override
    public void loadRace(final File theRaceFile) throws IOException {
        try {
            final Scanner file = new Scanner(theRaceFile);
            final boolean header = theHeader(file);
            final boolean participants = theParticipants(file);
            final boolean raceEntries = theRaceEntries(file);

            if ((header == participants) && (header == raceEntries)) {
                participantColorSet();
                myPCS.firePropertyChange(PROPERTY_HEADER, null, myRaceHeader);
                myPCS.firePropertyChange(PROPERTY_PARTICIPANTS, null, myRaceParticipants);
                myPCS.firePropertyChange(PROPERTY_TOGGLE, null, myRacerIDandToggle);

            }
        } catch (final NoSuchElementException event) {
            throw new IOException();
        }

    }

    /**
     * Helper method to check if header is valid.
     * @param theRaceFile file for race header.
     * @return false if format is incorrect.
     * @throws IOException throws exception if format is incorrect.
     */
    private boolean theHeader(final Scanner theRaceFile) throws IOException {
        boolean valid = true;
        try {
            String[] parseArray;
            String hashtag = theRaceFile.nextLine();
            parseArray = hashtag.split(COLON);           
            if (parseArray.length == 2) {
                if ("#RACE".equals(parseArray[0])) {
                    myRaceName = parseArray[1];
                    valid = true;
                    hashtag = theRaceFile.nextLine();
                    parseArray = hashtag.split(COLON); 
                }

                if ("#TRACK".equals(parseArray[0])) {
                    myTrackGeometry = parseArray[1];
                    valid = true;
                    hashtag = theRaceFile.nextLine();
                    parseArray = hashtag.split(COLON); 
                }

                if ("#WIDTH".equals(parseArray[0])) {
                    myTrackWidth = Integer.parseInt(parseArray[1]);
                    valid = true;
                    hashtag = theRaceFile.nextLine();
                    parseArray = hashtag.split(COLON); 
                }

                if ("#HEIGHT".equals(parseArray[0])) {
                    myTrackHeight = Integer.parseInt(parseArray[1]);
                    valid = true;
                    hashtag = theRaceFile.nextLine();
                    parseArray = hashtag.split(COLON); 
                }

                if ("#DISTANCE".equals(parseArray[0])) {
                    myLapDistance = Double.parseDouble(parseArray[1]);
                    valid = true;
                    hashtag = theRaceFile.nextLine();
                    parseArray = hashtag.split(COLON); 
                }

                if ("#TIME".equals(parseArray[0])) {
                    myTotalRaceTime = Integer.parseInt(parseArray[1]);

                    valid = true;
                    hashtag = theRaceFile.nextLine();
                    parseArray = hashtag.split(COLON); 
                }

                if ("#PARTICIPANTS".equals(parseArray[0])) {
                    myRacers = parseArray[1];
                    valid = true;
                } else {
                    throw new IOException();
                }
            }
            myRaceHeader = new Header(myRaceName, myTrackGeometry, 
                                myTrackWidth, myTrackHeight, myLapDistance, myTotalRaceTime);
        } catch (final NumberFormatException event) {
            throw new IOException();
        }

        return valid;

    }

    /**
     * Helper method to check if Participants is valid.
     * @param theRaceFile file for race header.
     * @return false if format is incorrect.
     * @throws IOException throws io for errors in file.
     */
    private boolean theParticipants(final Scanner theRaceFile) throws IOException {

        String hashtag = theRaceFile.nextLine();
        String[] parseArray = hashtag.split(COLON);
        final int participants = Integer.valueOf(myRacers);
        final boolean valid = true;
        final ArrayList<String[]> racerList = new ArrayList<>();
        try {
            for (int i = 1; i <= participants; i++) {
                if (parseArray.length == RACERARRAY) {
                    final String[] temp = new String[TRUEFALSEARRAY];
                    final String[] tempRaceID = parseArray[0].split(HASH);
                    final String racerID = tempRaceID[1];
                    myRacerIDandToggle.put(Integer.parseInt(racerID), true);
                    Double.parseDouble(parseArray[2]);
                    parseArray[0] = racerID;
                    temp[0] = racerID;
                    temp[1] = parseArray[1];
                    temp[2] = parseArray[2];
                    temp[RACERARRAY] = "";
                    racerList.add(temp);
                    if (i <= participants - 1) {
                        hashtag = theRaceFile.nextLine();
                        parseArray = hashtag.split(COLON);
                    }
                } else {
                    throw new IOException();
                }
            }   
        } catch (final NumberFormatException event) {
            throw new IOException();
        }
        myRaceParticipants = new Participants(racerList);

        myMessagelist = new ArrayList<>();
        for (int i = 0; i < myTotalRaceTime; i++) {
            myMessagelist.add(new ArrayList<>());
        }

        return valid;
    }

    /**
     * Helper method to check if Participants is valid.
     * @param theRaceFile file for race header.
     * @return false if format is incorrect.
     * @throws IOException throws io exception to gui for file error.
     */
    private boolean theRaceEntries(final Scanner theRaceFile) throws IOException {

        final int participants = Integer.valueOf(myRacers);
        final boolean valid = true;
        while (theRaceFile.hasNextLine()) {
            final String hashtag = theRaceFile.nextLine();
            final String[] parseArray = hashtag.split(COLON); 
            try {
                if ("$T".equals(parseArray[0]) && parseArray.length == ARRAYSIZE) {
                    telemetryT(parseArray);     
                }  else if ("$L".equals(parseArray[0])
                                && parseArray.length == (LEADERB + participants)) {
                    leaderboardL(parseArray);
                } else if ("$C".equals(parseArray[0]) && parseArray.length == ARRAYSIZE) {
                    lineCrossingC(parseArray);
                } else {
                    throw new IOException(); 
                } 

            } catch (final NumberFormatException event) {
                throw new IOException();
            }
        } 
        return valid;
    }

    /**
     * helper Method for telemetry parsing.
     * @param theArray array to be parsed
     */
    private void telemetryT(final String[] theArray) {
        final String[] parseArray = theArray;

        if ((Integer.parseInt(parseArray[2]) < MAXID)
                        && (Integer.parseInt(parseArray[2]) > 0)) {
            final String dollarT = parseArray[0];
            final int tempTS = Integer.parseInt(parseArray[1]);
            final int tempRID = Integer.parseInt(parseArray[2]);
            final double tempDistance = Double.parseDouble(parseArray[RACERARRAY]);
            final int tempLap = Integer.parseInt(parseArray[TRUEFALSEARRAY]);
            myMessagelist.get(tempTS).add
                (new TelemetryMessage(dollarT, tempTS, tempRID,
                                  tempDistance, tempLap));   
        }
    }

    /**
     * helper Method for leaderboard parsing.
     * @param theArray array to be parsed
     */
    private void leaderboardL(final String[] theArray) {
        final String[] parseArray = theArray;
        final int participants = Integer.valueOf(myRacers);

        final String dollarL = parseArray[0];
        final int tempLS = Integer.parseInt(parseArray[1]);
        final int[] testParticipants = new int[participants];
        for (int i = 2; i < participants + 2; i++) {
            testParticipants[i - 2] = Integer.parseInt(parseArray[i]);
        }
        myMessagelist.get(tempLS).add
            (new LeaderboardMessage(dollarL, tempLS, testParticipants));
    }

    /**
     * helper Method for line crossing message parsing.
     * @param theArray array to be parsed
     */
    private void lineCrossingC(final String[] theArray) {
        final String[] parseArray = theArray;

        if (TRUE.equals(parseArray[TRUEFALSEARRAY]) 
                        || FALSE.equals(parseArray[TRUEFALSEARRAY])) {
            final String dollarC = parseArray[0];
            final int tempCS = Integer.parseInt(parseArray[1]);
            final int tempRID = Integer.parseInt(parseArray[2]);
            final int tempLap = Integer.parseInt(parseArray[RACERARRAY]);
            boolean tempBoolean = true;
            if (TRUE.equals(parseArray[TRUEFALSEARRAY])) {
                tempBoolean = true;
            }
            if (FALSE.equals(parseArray[TRUEFALSEARRAY])) {
                tempBoolean = false;
            }
            myMessagelist.get(tempCS).add(
                        new LineCrossingMessage(dollarC, tempCS, tempRID, tempLap,
                                                                  tempBoolean));
        }
    }

    @Override
    public void addPropertyChangeListener(final PropertyChangeListener theListener) {
        myPCS.addPropertyChangeListener(theListener);

    }

    @Override
    public void addPropertyChangeListener(final String thePropertyName,
                                          final PropertyChangeListener theListener) {
        myPCS.addPropertyChangeListener(thePropertyName, theListener);

    }

    @Override
    public void removePropertyChangeListener(final PropertyChangeListener theListener) {
        myPCS.removePropertyChangeListener(theListener);

    }

    @Override
    public void removePropertyChangeListener(final String thePropertyName,
                                             final PropertyChangeListener theListener) {
        myPCS.removePropertyChangeListener(thePropertyName, theListener);

    }

}
