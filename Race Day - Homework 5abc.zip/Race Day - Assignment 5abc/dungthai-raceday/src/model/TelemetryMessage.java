/*
 * TCSS 305 - Winter 2019 Assignment 5 - Race Day
 */

package model;

import java.text.DecimalFormat;

/**
 * Subclass that stores the telemetry messages for the race.
 * @author Dung Thai
 * @version 8 March 2019
 *
 */
public class TelemetryMessage extends AbstractMessage {
    
    /** Colon string.
     */
    private static final String COLON = ":";
    
    /** Timestamp object.
     */
    private final int myTimestamp;

    /** Racer ID object.
     */
    private final int myRacerID;

    /** Distance object.
     */
    private final double myDistance;
    
    /** Lap object.
     */
    private final int myLap;
    
    /** DollarSign T.
     */
    private final String myT;
    
    /**
     * numberformat for double.
     */
    private final DecimalFormat myDF;

    /**
     * The constructor that initializes the objects.
     * @param theT Dollar sign T
     * @param theTimestamp the timestamp of the racer.
     * @param theRacerID racer ID. 
     * @param theDistance the current distance of the racer.
     * @param theLap the current lap the racer is on.
     */
    public TelemetryMessage(final String theT, final int theTimestamp, final int theRacerID,
                            final double theDistance, final int theLap) {
        super(theTimestamp);
        myT = theT;
        myTimestamp = theTimestamp;
        myRacerID = theRacerID;
        myDistance = theDistance;
        myLap = theLap;
        myDF = (DecimalFormat) DecimalFormat.getNumberInstance();
        myDF.setGroupingUsed(false);


    }
    
    /**
     * gets Dollarsign.
     * @return Dollarsign L.
     */
    public String getDollarSign() {
        return myT;
    }
    
    /**
     * gets racerID.
     * @return racer ID
     */
    public int getRacerID() {
        
        return myRacerID;
    }
    
    /**
     * gets lap.
     * @return lap
     */
    public int getRacerLap() {
        
        return myLap;
    }
    
    /**
     * gets racer distance.
     * @return racer distance
     */
    public double getRacerDistance() {
        
        return myDistance;
    }

    @Override
    public String toString() {

        return  myT + COLON + myTimestamp + COLON 
                        + myRacerID + COLON 
                        + myDF.format(Double.valueOf(myDistance))
                        + COLON + myLap;

    }
  
}
