/*
 * TCSS 305 - Winter 2019 Assignment 5 - Race Day
 */

package model;

/**
 * The Message Interface that gets the timestamp for the race.
 * @author Dung Thai
 * @version 9 March 2019
 *
 */
public interface Message {

    
    /**
     * Gets the timestamp from the message.
     * @return the timestamp when called
     */
    int getTimestamp();
    
    /**
     * Gets the header from the message.
     * @return the header when called
     */
    String toString();

}
