/*
 * TCSS 305 - Winter 2019 Assignment 5 - Race Day
 */


package model;


/**
 * Subclass that stores the line crossing messages for the race.
 * @author Dung Thai
 * @version 9 March 2019
 *
 */
public class LineCrossingMessage extends AbstractMessage {
    
    /** Colon string.
     */
    private static final String COLON = ":";
    
    /** Timestamp object.
     */
    private final int myTimestamp;
    
    /** Racer ID object.
     */
    private final int myRacerID;
    
    /** Lap object.
     */
    private final int myLap;
    
    /** dollar Sign C.
     */
    private final String myC;
    
    
    /** Object if the racer is finish or not.
     */
    private final boolean myFinish;

    /**
     * The constructor for the racer crossing the line.
     * @param theC dollarSign C.
     * @param theTimestamp the current timestamp.
     * @param theRacerID the racer who crosses the line.
     * @param theLap the current lap.
     * @param theFinish if the racer is finished or has to continue race.
     */
    public LineCrossingMessage(final String theC, final int theTimestamp, 
                             final int theRacerID, final int theLap, final boolean theFinish) {
        super(theTimestamp);
        myC = theC;
        myTimestamp = theTimestamp;
        myRacerID = theRacerID;
        myLap = theLap;
        myFinish = theFinish;
    }

    /**
     * gets the Dollar symbol.
     * @return Dollarsign c.
     */
    public String getDollarSign() {
        return myC;
    }
    
    /**
     * gets racerID.
     * @return racerID
     */
    public int getRacerID() {
        return myRacerID;
    }

    @Override
    public String toString() {
        return myC + COLON + myTimestamp + COLON 
                        + myRacerID + COLON + myLap
                        + COLON + Boolean.toString(myFinish);
        
    }
}
