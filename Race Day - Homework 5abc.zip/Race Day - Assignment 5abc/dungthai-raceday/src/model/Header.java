/*
 * TCSS 305 - Winter 2019 Assignment 5 - Race Day
 */


package model;

/**
 * Header Class that stores all the header Information.
 * @author Dung Thai
 * @version 9 March 2019
 *
 */
public class Header {
    
    /**
     * my Race title.
     */
    private final String myRace;
    
    /**
     * the track type.
     */
    private final String myTrack;
    
    /**
     * the track width.
     */
    private final int myWidth;
    
    /**
     * the track height.
     */
    private final int myHeight;
    
    /**
     * the total distance of the race.
     */
    private final double myDistance;
    
    /**
     * the total time of the race.
     */
    private final int myTime;
    
    /**
     * the Constructor for the header information class.
     * @param theRace the race name.
     * @param theTrack the track type.
     * @param theWidth the width of the track.
     * @param theHeight the height of the track.
     * @param theDistance the total distance.
     * @param theTime the total time.
     */
    public Header(final String theRace, final String theTrack, final int theWidth, 
                   final int theHeight, final double theDistance, final int theTime) {
        myRace = theRace;
        myTrack = theTrack;  
        myWidth = theWidth; 
        myHeight = theHeight;  
        myDistance = theDistance;
        myTime = theTime;
    }
    
    /**
     * gets total time of the track.
     * @return the total time
     */
    public int getTime() {
        
        return myTime;
    }
    
    /**
     * gets the name of the race.
     * @return the name of the race.
     */
    public String getRaceName() {
        
        return myRace;
    }

    /**
     * gets the width of the track.
     * @return the width of the track.
     */
    public int getWidth() {
        return myWidth;
    }
    /**
     * gets the height of the track.
     * @return the height of the track.
     */
    public int getHeight() {
        return myHeight;
    }
    
    /**
     * gets the track type.
     * @return string of track type.
     */
    public String trackName() {
        return myTrack;
    }
    
    /**
     * gets distance of the race.
     * @return the total distance of the race in double.
     */
    public double getTotalDistance() {
        
        return myDistance;
    }
    
    
}
