/*
 * TCSS 305 - Winter 2019 Assignment 5 - Race Day
 */


package model;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * object containing participant information.
 * @author Dung Thai
 * @version 9 March 2019
 */
public class Participants {
    
    /**
     * item 3 in array.
     */
    private static final int ARRAY2 = 2;
    
    /**
     * comma to parse array.
     */
    private static final String COMMA = ",";

    /**
     * total number of participants for this race.
     */
    private final int myTotalParticipants;
    
    
    /**
     * array containing all participant information.
     */
    private final ArrayList<String[]> myParticipants;
    
    /**
     * constructor that takes in an array with participants and intializes variables.
     * @param theParticipants the participant array.
     */
    public Participants(final ArrayList<String[]> theParticipants) {
        myParticipants = theParticipants;
        myTotalParticipants = theParticipants.size();
    }
    
    /**
     * gets Racer id.
     * @param theRacerIndex Array id is in.
     * @return Racer ID.
     */
    public int getRacerID(final int theRacerIndex) {
        String[] parse;
        int racerID = 0;
        for (int i = 0; i < myTotalParticipants; i++) {
            parse = Arrays.deepToString(myParticipants.get(theRacerIndex)).split(COMMA);
            racerID = Integer.parseInt(parse[0].substring(1));
        }
        return racerID;
    }
    
    /**
     * get racer name.
     * @param theRacerName array name is in.
     * @return racer name.
     */
    public String getRacerName(final int theRacerName) {
        String[] parse;
        String racerName = "";
        for (int i = 0; i < myParticipants.size(); i++) {
            parse = Arrays.deepToString(myParticipants.get(theRacerName)).split(COMMA);
            racerName = parse[1];
        }
        return racerName;
    }
    
    /**
     * get racer total time.
     * @param theRacerTime array time is in.
     * @return the racer time.
     */
    public double getRacerTime(final int theRacerTime) {
        String[] parse;
        double racerTime = 0;
        for (int i = 0; i < myParticipants.size(); i++) {
            parse = Arrays.deepToString(myParticipants.get(theRacerTime)).split(COMMA);
            racerTime = Double.parseDouble(parse[ARRAY2]);
        }
        return racerTime;
    }
    
    /**
     * the  number of participants.
     * @return total participants.
     */
    public int getNumberOfParticipants() {
        return myTotalParticipants;
    }
}
