/*
 * TCSS 305 - Winter 2019 Assignment 5 - Race Day
 */

package model;

/**
 * The abstract class for sharing the methods that leaderboard, linecrossing, and telemetry
 * has in common.
 * @author Dung Thai
 * @version 8 March 2019
 *
 */
public abstract class AbstractMessage implements Message {
    
    /** Timestamp object.
     */
    private final int myTimestamp;

    /**
     * The constructor that takes in the argument of the timestamp.
     * @param theTimestamp the timestamp of the racer.
     */
    public AbstractMessage(final int theTimestamp) {
        super();
        myTimestamp = theTimestamp;
    }
    
    /** Returns the timestamp of the racer.
     */
    @Override
    public int getTimestamp() {
       
        return myTimestamp;
    }

  /**
  * get racer information.
  * @return racer array.
  */
    public int[] getRacers() {
    
        return new int[1];
    }

}
