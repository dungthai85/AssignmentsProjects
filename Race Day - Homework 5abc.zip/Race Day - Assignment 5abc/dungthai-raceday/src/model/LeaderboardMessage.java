/*
 * TCSS 305 - Winter 2019 Assignment 5 - Race Day
 */

package model;

/**
 * Subclass that stores the leaderboard messages for the race.
 * @author Dung Thai
 * @version 9 March 2019
 *
 */
public class LeaderboardMessage extends AbstractMessage {
    
    /** Colon string.
     */
    private static final String COLON = ":";

    /** Timestamp object.
     */
    private final int myTimestamp;
    
    /** Dollar Sign L.
     */
    private final String myL;
    
    /** Array of racer IDs in the order the won.
     */
    private final int[] myRacers;

    /**
     * The constructor that initializes the objects.
     * @param theL the Dollarsign L
     * @param theTimestamp timestamp that is tracked.
     * @param theRacers array of racers in the order at that timestamp.
     */
    public LeaderboardMessage(final String theL, final int theTimestamp, 
                              final int[] theRacers) {
        super(theTimestamp);
        myL = theL;
        myTimestamp = theTimestamp;
        myRacers = theRacers;
//      
//      for (int i = 0; i < theRacers.length; i++) {
//          myRacers[i] = theRacers[i];
//      }
    }
    
    /**
     * method returns dollar sign L.
     * @return myL
     */
    public String getDollarSign() {
        return myL;
    }
    
    @Override
    public int[] getRacers() {
        return myRacers;
    }
    

    @Override
    public String toString() {
        final String message = myL + COLON + myTimestamp; 
        String racers = "";
        for (int i = 0; i < myRacers.length; i++) {
            racers = racers + COLON + myRacers[i];
        }
        return message + racers;
        
    }

}
