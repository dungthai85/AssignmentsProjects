/*
 * TCSS 305 - Winter 2019 Assignment 5 - Race Day
 */

package view;

import static model.PropertyChangeEnabledRaceControls.PROPERTY_TIME;

import java.awt.BorderLayout;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.text.DecimalFormat;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *  creates the Status bar. copied time panel and added the label to the panel.
 * @author Charles Bryan
 * @author Dung Thai
 * @version 16 March 2019
 *
 */
public class StatusBar extends JPanel implements PropertyChangeListener {
    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    /** The separator for formatted. */
    private static final String TIME = "Time:   ";
    
    /** The separator for formatted. */
    private static final String SPACE = "  ";
    

    /** The separator for formatted. */
    private static final String SEPARATOR = ":";

    /** The number of milliseconds in a second. */
    private static final int MILLIS_PER_SEC = 1000;

    /** The number of seconds in a minute. */
    private static final int SEC_PER_MIN = 60;

    /** The number of minute in a hour. */
    private static final int MIN_PER_HOUR = 60;

    /** A formatter to require at least 2 digits, leading 0s. */
    private static final DecimalFormat TWO_DIGIT_FORMAT = new DecimalFormat("00");

    /** A formatter to require at least 3 digits, leading 0s. */
    private static final DecimalFormat THREE_DIGIT_FORMAT = new DecimalFormat("000");

    
//    /** Participant object that contains participants information.
//     */
//    private Participants myParticipants;
//    
//    /**
//     * List containing participant id ad name
//     */
//    private Map<Integer, String> myParticipantList;
//    
//    /**
//     *  list containing Telemtry message.
//     */
//    private ArrayList<TelemetryMessage> messageTelemetry;
    
    /** A label to display time. */
    private final JLabel myTimeLabel;
    
    /**
     * constructor for statusBar.
     */
    public StatusBar() {
        super();
        
        myTimeLabel = new JLabel(TIME + formatTime(0) + SPACE);
        setLayout(new BorderLayout());
        final JLabel participantLabel = new JLabel();
        participantLabel.setText("   Participant:    ");
        final JLabel participantStatus = new JLabel();
        participantStatus.setText("");
        add(participantLabel, BorderLayout.WEST);
        add(participantStatus, BorderLayout.CENTER);
        add(myTimeLabel, BorderLayout.EAST);
    }
    
    /**
     * This formats a positive integer into minutes, seconds, and milliseconds. 
     * 00:00:000
     * @param theTime the time to be formatted
     * @return the formated string. 
     */
    public String formatTime(final long theTime) {
        long time = theTime;
        final long milliseconds = time % MILLIS_PER_SEC;
        time /= MILLIS_PER_SEC;
        final long seconds = time % SEC_PER_MIN;
        time /= SEC_PER_MIN;
        final long min = time % MIN_PER_HOUR;
        time /= MIN_PER_HOUR;
        return TWO_DIGIT_FORMAT.format(min) + SEPARATOR
                        + TWO_DIGIT_FORMAT.format(seconds) 
                        + SEPARATOR + THREE_DIGIT_FORMAT.format(milliseconds);
    }

    // was attempting to do the extra credit. but put too much time. maybe in 
    // the summer when i 
    // have time
    @Override
    public void propertyChange(final PropertyChangeEvent theEvent) {
        if (PROPERTY_TIME.equals(theEvent.getPropertyName())) {
            myTimeLabel.setText(TIME + formatTime((Integer) theEvent.getNewValue()) + SPACE);
        }
//        if (PROPERTY_PARTICIPANTS.equals(theEvent.getPropertyName())) {
//            myParticipants = (Participants) theEvent.getNewValue();
//            myParticipantList = new HashMap();
//            for (int i = 0; i < myParticipants.getNumberOfParticipants(); i++) {
//                myParticipantList.put(myParticipants.getRacerID(i), myParticipants.
//                                      getRacerName(i));
//            }
//        }
//        if (PROPERTY_TELEMETRY.equals(theEvent.getPropertyName())) {
//            final ArrayList<TelemetryMessage> message = 
//                            (ArrayList<TelemetryMessage>) theEvent.getNewValue();
//            messageTelemetry = new ArrayList<>();
//            for (int i = 0; i < message.size(); i++) {
//                if (message.get(i) instanceof TelemetryMessage) {
//                    messageTelemetry.add(message.get(i));
//                }
//            }
//
//        }
//        if (PROPERTY_STATUSBAR.equals(theEvent.getPropertyName())) {
//            int racerID = (int) theEvent.getNewValue();
//            System.out.println(racerID);
//            myParticipantStatus.setText("     #" + String.valueOf(racerID)
//            + "~~~~~~~" + myParticipantList.get(racerID) + "~~~~~~~"
//            + "  Lap:   " + messageTelemetry.get(racerID).getRacerLap() + "  Distance:  " + 
//                            messageTelemetry.get(racerID).getRacerDistance());
//        }
    }

}
