/*
 * TCSS 305 - Winter 2019 Assignment 5 - Race Day
 */

package view;

import static model.PropertyChangeEnabledRaceControls.PROPERTY_HEADER;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import model.RaceDay;

/**
 * Race Track View with leaderboard, track and statusbar.
 * @author Dung Thai
 * @version 16 March 2019
 *
 */
public class RaceTrackGUI extends JFrame implements PropertyChangeListener {
    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    /**
     * Title for frame.
     */
    private static final String TITLE = "Race Track";
    
    /**
     * size for panel.
     */
    private static final int HEIGHT = 500;
    
    /**
     * width size for panel.
     */
    private static final int WIDTHLARGE = 400;
    
    /**
     * width size for small panel.
     */
    private static final int WIDTHSMALL = 150;
    
    /** The flag icon for about and frame.
     */
    private static final String FLAGICON = "./images/flagiconred.jpg";
    
    /**
     * Race day object for track Panel.
     */
    private JPanel myTrackPanel;
    
    /**
     * race day track.
     */
    private final TrackPanel myFullTrack;
    
    /**
     * Race day object for status bar Panel.
     */
    private final StatusBar myStatusBar;
    
    /**
     * race leaderboardPanel.
     */
    private final LeaderboardPanel myLeaderboardPanel;
    
    /**
     * Race Track GUI Constructor.
     * @param theRace 
     */
    public RaceTrackGUI(final RaceDay theRace) {
        // Sets Title on JFrame
        super(TITLE);
        myLeaderboardPanel = new LeaderboardPanel();
        myFullTrack = new TrackPanel();
        myStatusBar = new StatusBar();
        theRace.addPropertyChangeListener(this);
        theRace.addPropertyChangeListener(myLeaderboardPanel);
        theRace.addPropertyChangeListener(myFullTrack);
        theRace.addPropertyChangeListener(myStatusBar);


        
        initGUI();
        setVisible(true);
    }
    
    /**
     * adds all panels to the frame of this view.
     */
    private void initGUI() {
        this.setLocationRelativeTo(null);
        this.setIconImage(new ImageIcon(FLAGICON).getImage());
        this.setLayout(new BorderLayout());
        myTrackPanel = new JPanel();
        myTrackPanel.setPreferredSize(new Dimension(HEIGHT, WIDTHLARGE));
        myTrackPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.
                                createLineBorder(Color.DARK_GRAY), TITLE));
        myTrackPanel.setBackground(Color.WHITE);
        myLeaderboardPanel.setSize(HEIGHT, WIDTHSMALL);
        add(myStatusBar, BorderLayout.SOUTH);
        add(myTrackPanel, BorderLayout.CENTER);
        add(myLeaderboardPanel, BorderLayout.EAST);
        setResizable(false);
        pack();
        
    }

    @Override
    public void propertyChange(final PropertyChangeEvent theEvent) {
        if (PROPERTY_HEADER.equals(theEvent.getPropertyName())) {
            myTrackPanel.setBorder(null);
            myTrackPanel.add(myFullTrack, BorderLayout.NORTH);
        }
    }

    

}
