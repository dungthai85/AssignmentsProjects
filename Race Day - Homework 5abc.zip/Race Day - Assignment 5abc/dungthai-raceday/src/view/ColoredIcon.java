/*
 * TCSS 305 - Winter 2019 Assignment 5 - Race Day
 */

package view;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;
import javax.swing.Icon;

/**
 * Class to help draw icons for buttons.
 * @author Dung Thai
 * @version 16 March 2019
 *
 */
public class ColoredIcon implements Icon {
    
    /**
     * The size for icon.
     */
    private static final int SIZE = 15;
    /**
     * my color to be painted.
     */
    private final Color myColor;
    
    /**
     * constructor.
     * @param theColor the color being passed in.
     */
    public ColoredIcon(final Color theColor) {
        myColor = theColor;
    }

    @Override
    public int getIconHeight() {
        
        return SIZE;
    }

    @Override
    public int getIconWidth() {
       
        return SIZE;
    }

    @Override
    public void paintIcon(final Component theC, final Graphics theG, 
                          final int theX, final int theY) {
        final Graphics2D g2d = (Graphics2D) theG;

        final Ellipse2D ellipse = new Ellipse2D.Double(SIZE, SIZE, SIZE, SIZE);
        // for better graphics display
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                             RenderingHints.VALUE_ANTIALIAS_ON);

        g2d.setStroke(new BasicStroke(2f));
        g2d.setColor(myColor);
        g2d.fill(ellipse);



    }


}
