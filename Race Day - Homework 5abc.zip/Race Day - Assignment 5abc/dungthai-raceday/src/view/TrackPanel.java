/*
 * TCSS 305 - Winter 2019 Assignment 5 - Race Day
 */

package view;


import static model.PropertyChangeEnabledRaceControls.PROPERTY_COLOR;
import static model.PropertyChangeEnabledRaceControls.PROPERTY_HEADER;
import static model.PropertyChangeEnabledRaceControls.PROPERTY_TELEMETRY;
import static model.PropertyChangeEnabledRaceControls.PROPERTY_PARTICIPANTS;
import static model.PropertyChangeEnabledRaceControls.PROPERTY_TOGGLE;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Point2D;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.JPanel;
import model.Header;
import model.Participants;
import model.TelemetryMessage;
import track.VisibleRaceTrack;

/**
 * A demo of PropertyChangeListener and track.jar. 
 * Copied track panel and now added racers with color.
 * 
 * @author Charles Bryan
 * @author Dung Thai
 * @version 16 March 2019
 */
public class TrackPanel extends JPanel implements PropertyChangeListener {
    
    /**  
     * A generated serial version UID for object Serialization. 
     * http://docs.oracle.com/javase/7/docs/api/java/io/Serializable.html
     */
    private static final long serialVersionUID = 8385732728740430466L;
    
    /** The size of the Race Track Panel. */
    private static final Dimension TRACK_SIZE = new Dimension(500, 400);
    
    /** The x and y location of the Track. */
    private static final int OFF_SET = 40;

    /** The stroke width in pixels. */
    private static final int STROKE_WIDTH = 20;

    /** The size of participants moving around the track. */
    private static final int OVAL_SIZE = 20;
    
    /** The size 5 track. */
    private static final int SIZE5 = 5;
    
    /**
     * counter for first Action.
     */
    private int myCount;
    
    
    /** Participant object that contains participants information.
     */
    private Participants myParticipants;
    
    /** 
     * map that stores participants ID and Color if they are selected.
     */
    private Map<Integer, Color> myRacerIDandColor;
    
    /** 
     * map that stores participants ID and Boolean if they are selected.
     */
    private Map<Integer, Boolean> myRacerIDandToggle;
    
    /** 
     * Race Header Object information gets stored.
     */
    private Header myRaceHeader;
    
    /** The visible track. */
    private VisibleRaceTrack myTrack;
    
    /** The circle moving around the track. */
    private Ellipse2D myCircle;
    
    /**
     * Map containing racerID and Distance.
     */
    private Map<Integer, Double> myParticipantDistance;
    
    /**
     *  Array list taking in messages.
     */
    private ArrayList<TelemetryMessage> myMessage;
    
    /**
     *  Array list taking in messages.
     */
    private ArrayList<?> myMessageCheck;
    
    /**
     * ArrayList containing  only Telelmetry Messages.
     */
    private ArrayList<TelemetryMessage> myMessagetelemetry;
    
    /**
     * map to be checked.
     */
    private Map<?, ?> myMap;
    
    /**
     * map to be checked.
     */
    private Map<?, ?> myBooleanMap;
    
    /**
     * Construct a Track Panel. 
     */
    public TrackPanel() {
        super();
        setBorder(BorderFactory.createTitledBorder(BorderFactory.
                                  createLineBorder(Color.DARK_GRAY), "Race Track"));
        setPreferredSize(TRACK_SIZE);
        setBackground(Color.WHITE);
    }
    
    /**
     * Setup and layout components. Takes height from header.
     */
    private void setupComponents() {
        final int calcWidth = (int) TRACK_SIZE.getWidth() - (OFF_SET * 2);
        final int calcHeight = ((int) TRACK_SIZE.getWidth()  - 2 * OFF_SET) / SIZE5 
                        * myRaceHeader.getHeight();
        final int x = OFF_SET;
        final int y = (int) TRACK_SIZE.getHeight()  / 2 - calcHeight / 2;
        myTrack = new VisibleRaceTrack(x, y, calcWidth, calcHeight,
                                       (int) myRaceHeader.getTotalDistance());
        myCount = 0;
        myParticipantDistance = new HashMap<>();

    }
    
    /**
     * Paints the VisibleTrack with a single ellipse moving around it.
     * 
     * @param theGraphics The graphics context to use for painting.
     */
    @Override
    public void paintComponent(final Graphics theGraphics) {
        super.paintComponent(theGraphics);
        final Graphics2D g2d = (Graphics2D) theGraphics;

        // for better graphics display
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                             RenderingHints.VALUE_ANTIALIAS_ON);
        
        // paints track
        if (myTrack != null) {
            g2d.setPaint(Color.black);
            g2d.setStroke(new BasicStroke(STROKE_WIDTH));
            g2d.draw(myTrack);
        }
        // loop to paint start points
        if (myCount == 0) {
            for (int i = 0; i < myParticipants.getNumberOfParticipants(); i++) {
                final Point2D start = myTrack.getPointAtDistance(myParticipants.
                                                                 getRacerTime(i));
                myParticipantDistance.put(myParticipants.getRacerID(i), myParticipants.
                                        getRacerTime(i));
                myCircle = new Ellipse2D.Double(start.getX() - OVAL_SIZE / 2,
                                                start.getY() - OVAL_SIZE / 2,
                                                OVAL_SIZE,
                                                OVAL_SIZE);
                g2d.setPaint(myRacerIDandColor.get(myParticipants.getRacerID(i)));
                g2d.setStroke(new BasicStroke(1));
                g2d.fill(myCircle);
            }
        }
        
        //loop to paint race.
        for (int i = 0; i < myParticipants.getNumberOfParticipants(); i++) {
            if (myRacerIDandToggle.get(myParticipants.getRacerID(i))) {
                final Point2D current = 
                                myTrack.getPointAtDistance(myParticipantDistance.
                                                           get(myParticipants.getRacerID(i)));
                myCircle.setFrame(current.getX() - OVAL_SIZE / 2, 
                                  current.getY() - OVAL_SIZE / 2, 
                                  OVAL_SIZE, 
                                  OVAL_SIZE);
                g2d.setPaint(myRacerIDandColor.get(myParticipants.getRacerID(i)));
                g2d.setStroke(new BasicStroke(1));
                g2d.fill(myCircle);
            }
        }
        myCount++;
    }
    
    /**
     * helper method to help check map for toggle boolean list.
     */
    private void mapCheck() {
        for (int i = 0; i < myBooleanMap.size(); i++) {
            final Boolean tempBoolean = (Boolean) myBooleanMap.
                            get(myParticipants.getRacerID(i));
            
            myRacerIDandToggle.put(myParticipants.getRacerID(i), tempBoolean);
        }
    }
    
    /**
     * Check for Telemetry object.
     */
    private void messageCheck() {
        for (int i = 0; i < myMessageCheck.size(); i++) {
            if (myMessageCheck.get(i) instanceof TelemetryMessage) {
                myMessage.add((TelemetryMessage) myMessageCheck.get(i));
            }
        }
    }
    
    @Override
    public void propertyChange(final PropertyChangeEvent theEvent) {
        if (PROPERTY_COLOR.equals(theEvent.getPropertyName())) {
            myRacerIDandColor = new HashMap<>();
            myMap = (Map<?, ?>) theEvent.getNewValue();

        }
        if (PROPERTY_PARTICIPANTS.equals(theEvent.getPropertyName())) {
            myParticipants = (Participants) theEvent.getNewValue();
            for (int i = 0; i < myMap.size(); i++) {
                final Color tempColor = (Color) myMap.get(myParticipants.getRacerID(i));
                
                myRacerIDandColor.put(myParticipants.getRacerID(i), tempColor);
            }
            myCount = 0;
            setupComponents();   
        }
        if (PROPERTY_HEADER.equals(theEvent.getPropertyName())) {
            myRaceHeader = (Header) theEvent.getNewValue();
        }
        if (PROPERTY_TELEMETRY.equals(theEvent.getPropertyName())) {
            myMessageCheck = (ArrayList<?>) theEvent.getNewValue();
            myMessage = new ArrayList<TelemetryMessage>();
            messageCheck();
            for (int i = 0; i < myMessage.size(); i++) {
                for (int j = 0; j < myParticipants.getNumberOfParticipants(); j++) {
                    if (myParticipants.getRacerID(j) == myMessage.get(i).
                                    getRacerID()) {
                        myParticipantDistance.put(myParticipants.getRacerID(j),
                                                myMessage.get(i).getRacerDistance());
                    }
                }
            }
            repaint();
        }
        if (PROPERTY_TOGGLE.equals(theEvent.getPropertyName())) {
            myRacerIDandToggle = new HashMap<>();
            myBooleanMap = (Map<?, ?>) theEvent.getNewValue();
            mapCheck();
            repaint();
        }
    }
}


