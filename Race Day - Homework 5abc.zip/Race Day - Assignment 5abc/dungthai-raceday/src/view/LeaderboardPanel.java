/*
 * TCSS 305 - Winter 2019 Assignment 5 - Race Day
 */

package view;

import static model.PropertyChangeEnabledRaceControls.PROPERTY_LEADERBOARD;
import static model.PropertyChangeEnabledRaceControls.PROPERTY_PARTICIPANTS;
import static model.PropertyChangeEnabledRaceControls.PROPERTY_COLOR;
import static model.PropertyChangeEnabledRaceControls.PROPERTY_TOGGLE;
import static model.PropertyChangeEnabledRaceControls.PROPERTY_STATUSBAR;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JButton;
import javax.swing.JPanel;
import model.Message;
import model.Participants;

/**
 * Leaderboard Panel that show leaderboard during the race.
 * @author Dung Thai
 * @version 16 March 2019
 *
 */
public class LeaderboardPanel extends JPanel implements PropertyChangeListener {
    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    /**
     * dimension Height.
     */
    private static final int HEIGHT = 150;
    
    /**
     * dimension Width.
     */
    private static final int WIDTH = 400;
    
    /**
     * Grid height.
     */
    private static final int GRID = 10;
    
    /** Participant object that contains participants information.
     */
    private Participants myParticipants;
    
    /**
     * count for Initial setup for components.
     */
    private int myCount;

    /**
     * Racer names.
     */
    private String myRacersString;
    
    /**
     * array containing racer information.
     */
    private String[] myRacersIDparse;
    
    /** 
     * map that stores participants ID and Boolean if they are selected.
     */
    private Map<Integer, Boolean> myRacerIDandToggle;
    
    /** 
     * map that stores participants ID and Boolean if they are selected.
     */
    private Map<Integer, Color> myRacerIDandColor;
    
    /**
     * map to be checked.
     */
    private Map<?, ?> myColorMap;
    
    /**
     * map to be checked.
     */
    private Map<?, ?> myBooleanMap;
    
    /**
     * constructor for Panel.
     */
    public LeaderboardPanel() {
        super();
        setPreferredSize(new Dimension(HEIGHT, WIDTH));
        setBackground(Color.WHITE);
        setupComponents();
        setVisible(true);
        myCount = 0;
    }
    

    /**
     * Setup and layout components. 
     */
    private void setupComponents() {
        setLayout(new GridLayout(GRID, 1));

        
    }
    
    
    
    /**
     * helper method to go through and add all participants to Checkbox.
     */
    private void buttonToPanel() {
        if (myCount != 0) {
            removeAll();
            for (int j = 2; j < myRacersIDparse.length; j++) {
                for (int i = 0; i < myParticipants.getNumberOfParticipants(); i++) {
                    if (myRacersIDparse[j].equals(String.valueOf(myParticipants.
                              getRacerID(i))) && myRacerIDandToggle.get(myParticipants.
                                                                        getRacerID(i))) {
                        add(participantButton(myParticipants.
                                             getRacerName(i), myParticipants.getRacerID(i)));
                        
                    }
                }
            }
            validate();
        }
        myCount++;

    }
    
    /**
     * helper method to go through and add all participants to Checkbox.
     */
    private void initialButtonToPanel() {
        removeAll();
   
        for (int i = 0; i < myParticipants.getNumberOfParticipants(); i++) {
            add(participantButton(myParticipants.
                                       getRacerName(i), myParticipants.getRacerID(i)));
        }
        validate();
    }

    
    /**
     * helper method to create jButton with true values and add item listener.
     * @param theName name of racer to be added to Jbutton
     * @param theID the id to be sent over to the toggleParticipant.
     * @return jButton to be added to panel.
     */
    private JButton participantButton(final String theName, final int theID) {

        final JButton racerButton = new JButton(theID + " : " 
                        + theName, new ColoredIcon(myRacerIDandColor.get(theID)));
        racerButton.setAlignmentX(Component.LEFT_ALIGNMENT);
        racerButton.addMouseListener(new MouseListener() { //NO PMD says too many lines
            @Override
            public void mouseClicked(final MouseEvent theEvent) {
                firePropertyChange(PROPERTY_STATUSBAR, null, theID);
//                System.out.println(theID); started on exra credit but stopped
            }
            @Override
            public void mouseEntered(final MouseEvent theEvent) {
            }
            @Override
            public void mouseExited(final MouseEvent theEvent) {
            }
            @Override
            public void mousePressed(final MouseEvent theEvent) {
            }
            @Override
            public void mouseReleased(final MouseEvent theEvent) {
            }
        });
                 
        return racerButton;
    }

    @Override
    public void propertyChange(final PropertyChangeEvent theEvent) {
        
        if (PROPERTY_COLOR.equals(theEvent.getPropertyName())) {
            myRacerIDandColor = new HashMap<>();
            myColorMap = (Map<?, ?>) theEvent.getNewValue();              
        }
        if (PROPERTY_PARTICIPANTS.equals(theEvent.getPropertyName())) {
            myParticipants = (Participants) theEvent.getNewValue();
            for (int i = 0; i < myColorMap.size(); i++) {
                final Color tempColor = (Color) myColorMap.get(myParticipants.getRacerID(i));
                
                myRacerIDandColor.put(myParticipants.getRacerID(i), tempColor);
            }
            myCount = 0;
            repaint();
            initialButtonToPanel();
        }
        if (PROPERTY_LEADERBOARD.equals(theEvent.getPropertyName())) {
            myRacersString = ((Message) theEvent.getNewValue()).toString();   
            myRacersIDparse = myRacersString.split(":");
            repaint();
            buttonToPanel();
        }
        if (PROPERTY_TOGGLE.equals(theEvent.getPropertyName())) {
            myRacerIDandToggle = new HashMap<>();
            myBooleanMap = (Map<?, ?>) theEvent.getNewValue();
            for (int i = 0; i < myBooleanMap.size(); i++) {
                final Boolean tempBoolean = (Boolean) myBooleanMap.
                                get(myParticipants.getRacerID(i));
                
                myRacerIDandToggle.put(myParticipants.getRacerID(i), tempBoolean);
            }
            if (myCount > 0) {
                repaint();
                buttonToPanel();
            }
        }  
    }

}
