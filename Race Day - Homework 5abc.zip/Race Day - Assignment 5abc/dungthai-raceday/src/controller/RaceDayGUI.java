/*
 * TCSS 305 - Winter 2019
 * Assignment 5 - Race Day
 */

package controller;

import static model.PropertyChangeEnabledRaceControls.PROPERTY_HEADER;
import static model.PropertyChangeEnabledRaceControls.PROPERTY_PARTICIPANTS;
import static model.PropertyChangeEnabledRaceControls.PROPERTY_MESSAGES;
import static model.PropertyChangeEnabledRaceControls.PROPERTY_TIME;


import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSlider;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JToolBar;
import javax.swing.Timer;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import model.Header;
import model.Message;
import model.Participants;
import model.RaceDay;
import view.RaceTrackGUI;

/**
 * Race Day GUI
 * The Main frame controller that implements the ActionListner.
 * This will manipulate the race.
 * @author Dung Thai
 * @version 9 March 2019
 *
 */
public class RaceDayGUI extends JFrame implements PropertyChangeListener {
    
    /** The serial version UID.
     */
    private static final long serialVersionUID = 1L;

    /** The window title.
     */
    private static final String TITLE = "Race Day!";
    
    /** The String restart.
     */
    private static final String RESTART = "Restart";
    
    /** The String Loop Race.
     */
    private static final String LOOPRACE = "Loop Race";
    
    /** The String single race.
     */
    private static final String SINGLE = "Single Race";
    
    /** The String times one.
     */
    private static final String TIMESONE = "Times One";
    
    /** The String times four.
     */
    private static final String TIMESFOUR = "Times Four";
    
    /** The String Clear.
     */
    private static final String CLEAR = "Clear";
    
    /** The String play.
     */
    private static final String PLAY = "Play";
    
    /** The String pause.
     */
    private static final String PAUSE = "Pause";
    
    /** The String restart image.
     */
    private static final String RESTART_IMG = "./images/ic_restart.png";

    /** The String play image.
     */
    private static final String PLAY_IMG = "./images/ic_play.png";

    /** The String pause image.
     */
    private static final String PAUSE_IMG = "./images/ic_pause.png";

    /** The String one Times image.
     */
    private static final String ONETIMES_IMG = "./images/ic_one_times.png";

    /** The String four Times image.
     */
    private static final String FOURTIMES_IMG = "./images/ic_four_times.png";

    /** The repeat image.
     */
    private static final String REPEAT_IMG = "./images/ic_repeat.png";

    /** The repeat image.
     */
    private static final String LOOP_IMG = "./images/ic_repeat_color.png";

    /** The clear image.
     */
    private static final String CLEAR_IMG = "./images/ic_clear.png";  

    /** The flag icon for about and frame.
     */
    private static final String FLAGICON = "./images/flagiconred.jpg";
    
    /** Amount of milliseconds between each call to the timer. 
     */
    private static final int TIMER_FREQUENCY = 31; 
    
    /** Value for regular multiplier. */
    private static final int SPEED_REGULAR = 1;

    /** Value for fast multiplier. */
    private static final int SPEED_FAST = 4;
    
    /** Value for 3. 
     */
    private static final int NUMBER3 = 3;
    
    /** Major Tick Spacing. 
     */
    private static final int MAJORTICKS = 60000;
    
    /** Minor Tick Spacing.
     */
    private static final int MINORTICKS = 10000;
    
    /** The empty Border margin.
     */
    private static final int TEXTWIDTH = 50;
    
    /** The empty Border margin.
     */
    private static final int MARGIN = 10;
    
    /** The empty Border margin bottom.
     */
    private static final int MARGINBOTTOM = 25;
    
    /** The Total race time.
     */
    private int myTotalRaceTime;
    
    /** The timer to control how often to advance the Time object. 
     */ 
    private final Timer mySwingTimer;
    
    /** The time multiplier. */
    private int myMutiplier;
    
    /** The slider for race duration.
     */
    private JSlider mySlider;
    
    /** text area variable.
     */
    private JTextArea myTextArea;
    
    /** the race day menu item.
     */
    private JMenuItem myRaceDayInfo;
    
    /** the panel that contains checkboxes.
     */
    private JPanel myCheckboxPanel;
    

    /** Boolean object true or false.
     */
    private boolean mySingleLooped;
    
    /**
     * Race day object for Timer Panel.
     */
    private RaceDayTimer myRaceDayTimer;
    
    /** The Actions for the ToolBar and Control Menu. 
     */
    private final List<Action> myActions;
    
    /** List for buttons added on tool bar.
     */
    private List<JButton> myButtons;
    
    /**list for menu items from control.
     */
    private List<JMenuItem> myMenu;
    
    /**list for check boxes for participants.
     */
    private List<JCheckBox> myCheckBoxParticipants;
    
    /** Complete race day object.
     */
    private final RaceDay myCompleteRace;
    
    /** Header object that contains header information.
     */
    private Header myRaceHeader;
    
    /** Participant object that contains participants information.
     */
    private Participants myParticipants;
    
    /**
     * Constructs a new RoadRageGUI, using the files in the current working
     * directory.
     */
    public RaceDayGUI() {
        // Sets Title on JFrame
        super(TITLE);
        myCompleteRace = new RaceDay();
        myCompleteRace.addPropertyChangeListener(this);
        mySwingTimer = new Timer(TIMER_FREQUENCY, this::handleTimer);
        myActions = new ArrayList<>();
        myMutiplier = 1;
        mySingleLooped = false;
        this.setIconImage(new ImageIcon(FLAGICON).getImage());
        // Starts GUI
        initGUI();

        setVisible(true);
    }
    
    /**
     * Sets up the GUI.
     */
    private void initGUI() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // add action names to action list
        myActions.add(new RestartAction(RESTART));
        myActions.add(new PlayAction(PLAY));
        myActions.add(new TimesOneAction(TIMESONE));
        myActions.add(new SingleRaceAction(SINGLE));
        myActions.add(new ClearAction(CLEAR));
        // Menu Bar
        final JMenuBar menuBar = new JMenuBar();
        menuBar.add(fileMenu());
        menuBar.add(controlMenu());
        menuBar.add(helpMenu());
        // layout     
        myRaceDayTimer = new RaceDayTimer();
        //adding property change to race day timer
        myCompleteRace.addPropertyChangeListener(PROPERTY_TIME, myRaceDayTimer);

        final Container masterPanel = new JPanel(new BorderLayout());
        masterPanel.add(raceSlider(), BorderLayout.CENTER);
        masterPanel.add(myRaceDayTimer, BorderLayout.EAST);
        masterPanel.add(raceTabbedPane(), BorderLayout.SOUTH);

        this.setJMenuBar(menuBar); 
        
        
        add(raceToolBar(), BorderLayout.SOUTH);
        add(masterPanel, BorderLayout.CENTER);
        setResizable(false);
        pack();
        new RaceTrackGUI(myCompleteRace);
    }
    
    /**
     * A helper method to create file menu.
     * Contains Load race... to load the race file.
     * @return The file menu
     */
    private JMenu fileMenu() {
        final JMenu file = new JMenu("File");
        final JMenuItem loadRace = new JMenuItem("Load Race...");
        final JFileChooser chooser = new JFileChooser(".");
        final String stillLoading = "Load file: Still loading..." + System.lineSeparator();
        final String loadMessage = "Load file: Start - This may take a while. Please be"
                        + " patient." + System.lineSeparator()
                        + stillLoading + stillLoading
                        + stillLoading;
        loadRace.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent theEvent) {
                final int returnValue = chooser.showOpenDialog(null);
                try {
                    if (returnValue == JFileChooser.APPROVE_OPTION) {
                        final File raceFile = chooser.getSelectedFile();
                        mySlider.setValue(0);
                        myTextArea.setText(null);

                        myTextArea.append(loadMessage);
                        myCompleteRace.loadRace(raceFile);
                        myTextArea.append("Load file: Complete!" + System.lineSeparator());
                    }
                } catch (final IOException ioe) {
                    JOptionPane.showMessageDialog(null, "Error loading file.",  "Error!",
                                                  JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        file.add(loadRace);
        file.add(new JSeparator());
        final JMenuItem exitProgram = new JMenuItem("Exit");
        exitProgram.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent theEvent) {
                System.exit(0);
            }
        });
        file.add(exitProgram);
        
        return file;
    }

    /**
     * A helper method to create control menu.
     * contains Restart, Play/Pause, Onetimes Fourtimes, Clear
     * @return The control menu
     */
    private JMenu controlMenu() {
        final JMenu controls = new JMenu("Controls");
        myMenu = new ArrayList<>();
        for (final Action a : myActions) {
            final JMenuItem menu = new JMenuItem(a);
            menu.setEnabled(false);
            controls.add(menu);
            myMenu.add(menu);
   
           
        }

        return controls;
    }
    
    /**
     * A helper method to create help menu.
     * Contains Raceinfo and About.
     * @return The help menu
     */
    private JMenu helpMenu() {
        final JMenu help = new JMenu("Help");
        myRaceDayInfo = new JMenuItem("Race Info...");
        myRaceDayInfo.setEnabled(false);
        myRaceDayInfo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent theEvent) {
                final String aboutString = myRaceHeader.getRaceName() + System.lineSeparator() 
                    + "Track type: " + myRaceHeader.trackName() + System.lineSeparator() 
                    + "Total Time: " + myRaceDayTimer.formatTime(myRaceHeader.getTime()) 
                    + System.lineSeparator() + "Lap Distance: " 
                    + (int) myRaceHeader.getTotalDistance();
                JOptionPane.showMessageDialog(null, aboutString, "Race Information",
                                  JOptionPane.INFORMATION_MESSAGE);
            }
        });
        help.add(myRaceDayInfo);
        final ImageIcon aboutIcon = new ImageIcon(FLAGICON);
        final Image aboutimg = 
                        aboutIcon.getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT);
        final JMenuItem about = new JMenuItem("About...");
        about.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent theEvent) {
                final String aboutString = "Dung Thai" + System.lineSeparator() 
                    + "Winter 2019" + System.lineSeparator() + "TCSS 305";
                JOptionPane.showMessageDialog(null, aboutString, "About",
                                  JOptionPane.INFORMATION_MESSAGE, new ImageIcon(aboutimg));
            }
        });
        help.add(about);
        return help;
    }
    
    /**
     * A helper method to make a ToolBar.
     * Contains the Restart, Play/Pause, Onetimes, Repeat, and Clear buttons.
     * @return The Tool Bar
     */
    private JToolBar raceToolBar() {
        final JToolBar raceTool = new JToolBar();
        myButtons = new ArrayList<>();
        for (final Action a : myActions) {
            //add a button based on the action to the Tool Bar
            final JButton butt = new JButton(a);
            butt.setHideActionText(true); 
            butt.setEnabled(false);
            myButtons.add(butt);
            raceTool.add(butt);
        
        }

        return raceTool;
    }
    
    /**
     * A helper method to make the slider.
     * 
     * @return The my slider
     */
    private JSlider raceSlider() {
        mySlider = new JSlider();        
        mySlider.setBorder(BorderFactory.createEmptyBorder
                           (MARGINBOTTOM, MARGIN, MARGINBOTTOM, MARGIN));
        
        mySlider.setValue(0);
        mySlider.addChangeListener(new ChangeListener() {
            /** Called in response to slider events in this window. */
            @Override
            public void stateChanged(final ChangeEvent theEvent) {
                final int value = mySlider.getValue();
                    myCompleteRace.moveTo(value);
            }
        });

        mySlider.setEnabled(false);
        return mySlider;
    }
    
    /**
     * A helper method to make the tabbed panes.
     * 
     * @return The tabbedPane
     */
    private JTabbedPane raceTabbedPane() {
        final JTabbedPane tabbedPane = new JTabbedPane();
        myTextArea = new JTextArea(MARGIN, TEXTWIDTH);
        final JScrollPane scrollPane = new JScrollPane(myTextArea);
        myCheckboxPanel = new JPanel();
        
        scrollPane.setHorizontalScrollBar(null);
      
//        myCheckboxPanel.setLayout(new GridLayout(0, NUMBER3));


        tabbedPane.add("Data Output Stream", scrollPane);
        tabbedPane.add("Race Participants", myCheckboxPanel);

        tabbedPane.setBorder(BorderFactory.createEmptyBorder
                            (MARGIN, MARGIN, MARGIN, MARGIN));
        myTextArea.setEditable(false);
        return tabbedPane;
    }
    
    
    /**
     * Event handler for the timer. 
     * @param theEvent the fired event
     */
    private void handleTimer(final ActionEvent theEvent) { //NOPMD
        
        myCompleteRace.advance(TIMER_FREQUENCY * myMutiplier);

    }
    
    /**
     * helper method to enable all buttons after valid file is loaded.
     */
    private void enableAfterLoaded() {
        mySlider.setMajorTickSpacing(MAJORTICKS);
        mySlider.setMinorTickSpacing(MINORTICKS);
        myTotalRaceTime = myRaceHeader.getTime();
        mySlider.setMaximum(myTotalRaceTime);
        mySlider.setPaintTicks(true);
        mySlider.setEnabled(true);
        myRaceDayInfo.setEnabled(true);
        for (final JMenuItem a : myMenu) { 
            a.setEnabled(true);
        }
        for (final JButton a : myButtons) {    
            a.setEnabled(true);
        } 
    }
    
    /**
     * helper method to go through and add all participants to Checkbox.
     */
    private void checkboxToPanel() {
        for (int i = 0; i < myParticipants.getNumberOfParticipants(); i++) {

            myCheckboxPanel.add(participantCheckBox(myParticipants.
                            getRacerName(i), myParticipants.getRacerID(i)));
        }
    }
    
    /**
     * helper method to create checkboxes with true values and add item listener.
     * @param theName name of racer to be added to checkbox
     * @param theID the id to be sent over to the toggleParticipant.
     * @return checkbox to be added to panel.
     */
    private JCheckBox participantCheckBox(final String theName, final int theID) {

        final JCheckBox checkBox = new JCheckBox(theName, true);

        checkBox.addItemListener(new ItemListener() {

            @Override
            public void itemStateChanged(final ItemEvent theEvent) {
                if (theEvent.getStateChange() == ItemEvent.SELECTED) {
                    myCompleteRace.toggleParticipant(theID, true);
                } else if (theEvent.getStateChange() == ItemEvent.DESELECTED) {
                    myCompleteRace.toggleParticipant(theID, false);
                }
            }
        });

        myCheckBoxParticipants.add(checkBox);
            
 
        return checkBox;
    }
    


    /**
     * all the events from property listeners.
     */
    @Override
    public void propertyChange(final PropertyChangeEvent theEvent) {
        if (PROPERTY_TIME.equals(theEvent.getPropertyName())) {
            if ((int) theEvent.getNewValue() < myTotalRaceTime - 1) {
                mySlider.setValue((int) theEvent.getNewValue()); 
            }
            if (mySingleLooped && ((int) theEvent.getNewValue() >= myTotalRaceTime - 1)) {
                mySlider.setValue(0);
            }
            if (!mySingleLooped && ((int) theEvent.getNewValue() >= myTotalRaceTime - 1)) {
                mySwingTimer.stop();
                myActions.get(1).putValue(Action.NAME, PLAY);
                ((PlayAction) myActions.get(1)).setIcon(new ImageIcon(PLAY_IMG));
                mySlider.setEnabled(true);                
            }
        }
        
        if (PROPERTY_HEADER.equals(theEvent.getPropertyName())) {
            myRaceHeader = (Header) theEvent.getNewValue();
            enableAfterLoaded();
        }
        
        if (PROPERTY_PARTICIPANTS.equals(theEvent.getPropertyName())) {
            myCheckboxPanel.removeAll();
            myCheckBoxParticipants = new ArrayList<>();
            myCheckboxPanel.setLayout(new GridLayout(0, NUMBER3));
            myParticipants = (Participants) theEvent.getNewValue();
            checkboxToPanel();
        }
        
        if (PROPERTY_MESSAGES.equals(theEvent.getPropertyName())) {
            myTextArea.append(((Message) theEvent.getNewValue()).toString() 
                              + System.lineSeparator());       
        }
    }
    
    /**
     * An action to encapsulate the Restart Button.
     * @author Charles Bryan
     * @author Dung Thai
     * @version Winter 2019
     */
    class RestartAction extends AbstractAction {

        /**  
         * A generated serial version UID for object Serialization. 
         * http://docs.oracle.com/javase/7/docs/api/java/io/Serializable.html
         */
        private static final long serialVersionUID = 12367890L;

        /**
         * Construct a RestartAction. 
         * @param theText the title for the action
         */
        RestartAction(final String theText) {
            super(theText);
            
            setIcon(new ImageIcon(RESTART_IMG));
            
            //Or set the text using the put method instead of super(theText)
//            putValue(Action.NAME, theText);
        }

        @Override
        public void actionPerformed(final ActionEvent theEvent) {
            myCompleteRace.moveTo(0);
            myTextArea.setText(null);
        }

        
        /**
         * Helper to set the Icon to both the Large and Small Icon values. 
         * @param theIcon the icon to set for this Action 
         */
        private void setIcon(final ImageIcon theIcon) {
            final ImageIcon icon = (ImageIcon) theIcon;
            final Image largeImage =
                icon.getImage().getScaledInstance(24, 24, java.awt.Image.SCALE_SMOOTH);
            final ImageIcon largeIcon = new ImageIcon(largeImage);
            putValue(Action.LARGE_ICON_KEY, largeIcon);
            
            final Image smallImage =
                icon.getImage().getScaledInstance(12, -1, java.awt.Image.SCALE_SMOOTH);
            final ImageIcon smallIcon = new ImageIcon(smallImage);
            putValue(Action.SMALL_ICON, smallIcon);
        }
    }
    
    /**
     * An action to encapsulate the Play/Pause Button.
     * @author Charles Bryan
     * @author Dung Thai
     * @version Winter 2019
     */
    class PlayAction extends AbstractAction {

        /**  
         * A generated serial version UID for object Serialization. 
         * http://docs.oracle.com/javase/7/docs/api/java/io/Serializable.html
         */
        private static final long serialVersionUID = 12567890L;

        /**
         * Construct a StartAction. 
         * @param theText the title for the action
         */
        PlayAction(final String theText) {
            super(theText);
            
            setIcon(new ImageIcon(PLAY_IMG));
                        
            //Or set the text using the put method instead of super(theText)
//            putValue(Action.NAME, theText);
        }

        @Override
        public void actionPerformed(final ActionEvent theEvent) {
            if (mySwingTimer.isRunning()) {
                mySwingTimer.stop();
                mySlider.setEnabled(true);
                putValue(Action.NAME, PLAY);
                setIcon(new ImageIcon(PLAY_IMG));
            } else {
                mySwingTimer.start();
                mySlider.setEnabled(false);
                putValue(Action.NAME, PAUSE);
                setIcon(new ImageIcon(PAUSE_IMG));
            }
        }
    
    
        /**
         * Helper to set the Icon to both the Large and Small Icon values. 
         * @param theIcon the icon to set for this Action 
         */
        private void setIcon(final ImageIcon theIcon) {
            final ImageIcon icon = (ImageIcon) theIcon;
            final Image largeImage =
                icon.getImage().getScaledInstance(24, 24, java.awt.Image.SCALE_SMOOTH);
            final ImageIcon largeIcon = new ImageIcon(largeImage);
            putValue(Action.LARGE_ICON_KEY, largeIcon);
            
            final Image smallImage =
                icon.getImage().getScaledInstance(12, -1, java.awt.Image.SCALE_SMOOTH);
            final ImageIcon smallIcon = new ImageIcon(smallImage);
            putValue(Action.SMALL_ICON, smallIcon);
        }  
    }
    
    /**
     * An action to encapsulate the Times One/Times Four Button.
     * @author Charles Bryan
     * @author Dung Thai
     * @version Winter 2019
     */
    class TimesOneAction extends AbstractAction {

        /**  
         * A generated serial version UID for object Serialization. 
         * http://docs.oracle.com/javase/7/docs/api/java/io/Serializable.html
         */
        private static final long serialVersionUID = 1234567890L;

        /**
         * Construct a StartAction. 
         * @param theText the title for the action
         */
        TimesOneAction(final String theText) {
            super(theText);
            
            setIcon(new ImageIcon(ONETIMES_IMG));
            
            //Or set the text using the put method instead of super(theText)
//            putValue(Action.NAME, theText);
        }

        @Override
        public void actionPerformed(final ActionEvent theEvent) {
            if (myMutiplier == SPEED_REGULAR) {
                myMutiplier = SPEED_FAST;
                putValue(Action.NAME, TIMESFOUR);
                setIcon(new ImageIcon(FOURTIMES_IMG));
            } else {
                myMutiplier = SPEED_REGULAR;
                putValue(Action.NAME, TIMESONE);
                setIcon(new ImageIcon(ONETIMES_IMG));
            }
        }
    
        
        /**
         * Helper to set the Icon to both the Large and Small Icon values. 
         * @param theIcon the icon to set for this Action 
         */
        private void setIcon(final ImageIcon theIcon) {
            final ImageIcon icon = (ImageIcon) theIcon;
            final Image largeImage =
                icon.getImage().getScaledInstance(24, 24, java.awt.Image.SCALE_SMOOTH);
            final ImageIcon largeIcon = new ImageIcon(largeImage);
            putValue(Action.LARGE_ICON_KEY, largeIcon);
            
            final Image smallImage =
                icon.getImage().getScaledInstance(12, -1, java.awt.Image.SCALE_SMOOTH);
            final ImageIcon smallIcon = new ImageIcon(smallImage);
            putValue(Action.SMALL_ICON, smallIcon);
        }
    }
    
    
    /**
     * An action to encapsulate the Single Race/Loop race Button.
     * @author Charles Bryan
     * @author Dung Thai
     * @version Winter 2019
     */
    class SingleRaceAction extends AbstractAction {

        /**  
         * A generated serial version UID for object Serialization. 
         * http://docs.oracle.com/javase/7/docs/api/java/io/Serializable.html
         */
        private static final long serialVersionUID = 1234567890L;

        /**
         * Construct a StartAction. 
         * @param theText the title for the action
         */
        SingleRaceAction(final String theText) {
            super(theText);
            
            setIcon(new ImageIcon(REPEAT_IMG));
                        
            //Or set the text using the put method instead of super(theText)
//            putValue(Action.NAME, theText);
        }

        @Override
        public void actionPerformed(final ActionEvent theEvent) {
            if (mySingleLooped) {
                putValue(Action.NAME, SINGLE);
                setIcon(new ImageIcon(REPEAT_IMG));
                mySingleLooped = false;
            } else {
                putValue(Action.NAME, LOOPRACE);
                setIcon(new ImageIcon(LOOP_IMG));
                mySingleLooped = true;
            }
        }
    
        
        /**
         * Helper to set the Icon to both the Large and Small Icon values. 
         * @param theIcon the icon to set for this Action 
         */
        private void setIcon(final ImageIcon theIcon) {
            final ImageIcon icon = (ImageIcon) theIcon;
            final Image largeImage =
                icon.getImage().getScaledInstance(24, 24, java.awt.Image.SCALE_SMOOTH);
            final ImageIcon largeIcon = new ImageIcon(largeImage);
            putValue(Action.LARGE_ICON_KEY, largeIcon);
            
            final Image smallImage =
                icon.getImage().getScaledInstance(12, -1, java.awt.Image.SCALE_SMOOTH);
            final ImageIcon smallIcon = new ImageIcon(smallImage);
            putValue(Action.SMALL_ICON, smallIcon);
        }
    }
    
    
    /**
     * An action to encapsulate the Clear race Button.
     * @author Charles Bryan
     * @author Dung Thai
     * @version Winter 2019
     */
    class ClearAction extends AbstractAction {

        /**  
         * A generated serial version UID for object Serialization. 
         * http://docs.oracle.com/javase/7/docs/api/java/io/Serializable.html
         */
        private static final long serialVersionUID = 1234567890L;

        /**
         * Construct a StartAction. 
         * @param theText the title for the action
         */
        ClearAction(final String theText) {
            super(theText);
            
            setIcon(new ImageIcon(CLEAR_IMG));
                        
            //Or set the text using the put method instead of super(theText)
//            putValue(Action.NAME, theText);
        }

        @Override
        public void actionPerformed(final ActionEvent theEvent) {
            myTextArea.setText(null);
        }
    
        
        /**
         * Helper to set the Icon to both the Large and Small Icon values. 
         * @param theIcon the icon to set for this Action 
         */
        private void setIcon(final ImageIcon theIcon) {
            final ImageIcon icon = (ImageIcon) theIcon;
            final Image largeImage =
                icon.getImage().getScaledInstance(24, 24, java.awt.Image.SCALE_SMOOTH);
            final ImageIcon largeIcon = new ImageIcon(largeImage);
            putValue(Action.LARGE_ICON_KEY, largeIcon);
            
            final Image smallImage =
                icon.getImage().getScaledInstance(12, -1, java.awt.Image.SCALE_SMOOTH);
            final ImageIcon smallIcon = new ImageIcon(smallImage);
            putValue(Action.SMALL_ICON, smallIcon);
        }
    }
    

}
