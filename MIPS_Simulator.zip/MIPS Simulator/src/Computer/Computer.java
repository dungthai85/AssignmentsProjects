package Computer;

import BitString.BitString;

/**
 * Computer class comprises of memory, registers, cc and
 * can execute the instructions based on PC and IR 
 * @author Dung Thai
 * @author Ai Nguyen
 * @author Jiarui Xiong
 * @version 11-15-2019
 *
 */


public class Computer {

	/**  The number of memory in the MIPS simulator.  */
	private final static int MAX_MEMORY = 100;
	/**  The number of register in the MIPS simulator.  */
	private final static int MAX_REGISTERS = 32;

	/**  Array stores all registers.   */
	private BitString mRegisters[];
	/**  Array stores all memories.   */
	private BitString mMemory[];
	/**  BitString represents PC.  */
	private BitString mPC;
	/**  BitString represents IR.  */
	private BitString mIR;
	/**  BitString represents CC.  */
	private BitString mCC;

	/**
	 * Initializes all the memory to 0, registers to 0 to 7
	 * PC, IR to 16 bit 0s and CC to 000 
	 * Represents the initial state 
	 */
	public Computer() {
		mPC = new BitString();
		mPC.setValue(0);
		mIR = new BitString();
		mIR.setValue(0);
		mCC = new BitString();
		mCC.setBits(new char[] { '0', '0', '0' });
		mRegisters = new BitString[MAX_REGISTERS];
		for (int i = 0; i < MAX_REGISTERS; i++) {
			mRegisters[i] = new BitString();
			mRegisters[i].setValue(i);
		}

		mMemory = new BitString[MAX_MEMORY];
		for (int i = 0; i < MAX_MEMORY; i++) {
			mMemory[i] = new BitString();
			mMemory[i].setValue(0);
		}
	}

	/**
	 * Loads a 32 bit word into memory at the given address. 
	 * @param address memory address
	 * @param word data or instruction or address to be loaded into memory
	 */
	public void loadWord(int address, BitString word) {
		if (address < 0 || address >= MAX_MEMORY) {
			throw new IllegalArgumentException("Invalid address");
		}
		mMemory[address] = word;
	}
	
	/** Execute ADD instruction that adds two signed values from two sources into destination register.
	 * 
	 */
	public void executeADD() {
		BitString firstSource = mIR.substring(6, 5);
		
		BitString secondSource = mIR.substring(11, 5);
		
		BitString destSource = mIR.substring(16, 5);
		int temp = mRegisters[firstSource.getValue()].getValue2sComp();
		int temp1 = mRegisters[secondSource.getValue()].getValue2sComp();
		
		mRegisters[destSource.getValue()].setValue2sComp(temp + temp1);
		
	}
	
	
	/** Execute ADDU instruction that adds two unsigned values from two sources into destination register.
	 * 
	 */
	public void executeADDU() {
		BitString firstSource = mIR.substring(6, 5);
		BitString secondSource = mIR.substring(11, 5);
		int temp = mRegisters[firstSource.getValue()].getValue();
		int temp1 = mRegisters[secondSource.getValue()].getValue();
		
		BitString destSource = mIR.substring(16, 5);
		mRegisters[destSource.getValue()].setValue(temp + temp1);
	}
	
	
	/** Execute AND instruction that bitwise ands two registers and stores the result in a register.
	 * 
	 */
	public void executeAND() {
	
		BitString firstSource = mIR.substring(6, 5);
		
		BitString secondSource = mIR.substring(11, 5);
		
		BitString destSource = mIR.substring(16, 5);
		int sourceLength = mRegisters[firstSource.getValue()].getLength();

		char[] result = new char[sourceLength];
		for (int i = 0; i < sourceLength; i++) {
			char temp1 = mRegisters[firstSource.getValue()].getBits()[i];
			char temp2 = mRegisters[secondSource.getValue()].getBits()[i];
			if (temp1 == '1' && temp2 == '1') {
				result[i] = '1';
			} else {
				result[i] = '0';
			}
		}
		mRegisters[destSource.getValue()].setBits(result);	
	}
	

	/** Execute OR instruction that bitwise logical ors two registers and stores the result in a register.
	 * 
	 */
	public void executeOR() {
		BitString firstSource = mIR.substring(6, 5);
		
		BitString secondSource = mIR.substring(11, 5);
		
		BitString destSource = mIR.substring(16, 5);
		int sourceLength = mRegisters[firstSource.getValue()].getLength();
		char[] result = new char[sourceLength];
		for (int i = 0; i < sourceLength; i++) {
			char temp1 = mRegisters[firstSource.getValue()].getBits()[i];
			char temp2 = mRegisters[secondSource.getValue()].getBits()[i];
			if (temp1 == '0' && temp2 == '0') {
				result[i] = '0';
			} else {
				result[i] = '1';
			}
		}
		mRegisters[destSource.getValue()].setBits(result);
	}
	
	
	/** Execute ADDI instruction that adds a register and a sign-extended immediate value and stores the result in a register.
	 * 
	 */
	public void executeADDI() {
		BitString rs = mIR.substring(6, 5);
		BitString rt = mIR.substring(11, 5);
		BitString immediate = mIR.substring(16, 16);
		
		int total = mRegisters[rs.getValue()].getValue2sComp() + immediate.getValue2sComp();
		mRegisters[rt.getValue()].setValue2sComp(total);		
	}
	
	
	/** Execute ADDIU instruction that adds a register and a sign-extended immediate value and stores the result in a register.
	 * 
	 */
	public void executeADDIU() {
        BitString rs = mIR.substring(6, 5);

        BitString immediate = mIR.substring(16, 16); // immediate value
        BitString rt = mIR.substring(11, 5);

        int temp1 = mRegisters[rs.getValue()].getValue();
        int temp2 =  immediate.getValue();

        int temp3 = temp1 + temp2;

        mRegisters[rt.getValue()].setValue(temp3);

    }
	
	
	/** Execute ANDI instruction that bitwise ors a register and an immediate value and stores the result in a register.
	 * 
	 */
	public void executeANDI() {
		BitString firstSourceBS = mIR.substring(6, 5);
		BitString secondSourceBS = mIR.substring(16, 16);
		BitString destBS = mIR.substring(11, 5);
					
		char[] temp1 = mRegisters[firstSourceBS.getValue()].getBits();
		char[] temp2 = mRegisters[secondSourceBS.getValue()].getBits();
		char[] temp3 = new char[temp2.length];
		for (int i = 0; i < temp2.length; i++) {
			if (temp2[i] == '1' && temp1[i] == '1') {
				temp3[i] = '1';
			}
			else {
				temp3[i] = '0';
			}			
		}
		mRegisters[destBS.getValue()].setBits(temp3);
	}

	/** Execute ORI instruction that bitwise ors a register and an immediate value and stores the result in a register.
	 * 
	 */
	public void executeORI() {
		BitString firstSourceBS = mIR.substring(6, 5);
		BitString secondSourceBS = mIR.substring(16, 16);
		BitString destBS = mIR.substring(11, 5);
					
		char[] temp1 = mRegisters[firstSourceBS.getValue()].getBits();
		char[] temp2 = mRegisters[secondSourceBS.getValue()].getBits();
		char[] temp3 = new char[temp2.length];
		for (int i = 0; i < temp2.length; i++) {
			if (temp2[i] == '0' && temp1[i] == '0') {
				temp3[i] = '0';
			}
			else {
				temp3[i] = '1';
			}			
		}
		mRegisters[destBS.getValue()].setBits(temp3);
	}
	/** Execute LW instruction that a word is loaded into a register from the specified address.
	 * 
	 */
	public void executeLW() {
		BitString firstSourceBS = mIR.substring(6, 5);
		BitString immediate = mIR.substring(16, 16);
		BitString destBS = mIR.substring(11, 5);
//		int temp = mRegisters[firstSourceBS.getValue()].getValue();
		
		int temp = mRegisters[firstSourceBS.getValue()].getValue2sComp();
		mRegisters[destBS.getValue()] = mMemory[temp + ((immediate.getValue())/4)].copy(); 
	}
	
	
	/** Execute SW instruction that the contents of $t is stored at the specified address.
	 * 
	 */
	public void executeSW() {
		BitString firstSourceBS = mIR.substring(6, 5);
		BitString immediate = mIR.substring(16, 16);
		BitString destBS = mIR.substring(11, 5);
//		int temp = mRegisters[firstSourceBS.getValue()].getValue();
		int temp = mRegisters[firstSourceBS.getValue()].getValue2sComp();
		mMemory[temp + ((immediate.getValue())/4)] = mRegisters[destBS.getValue()];	
	}
	
	
	/** Execute J instruction that jumps to the destination address.
	 * 
	 */
	public void executeJ() {
		// PC = jump address
		BitString address = mIR.substring(6, 26);
		
		System.out.println("HHAHAL: "+address.display(true));
		System.out.println("VALUE: " + address.getValue());
		mPC.setValue(address.getValue()+1);	
	}
	
	
	/** Execute JR instruction that jumps to the address contained in register $s.
	 * 
	 */
	public void executeJR() {
		BitString firstSource = mIR.substring(6, 5);
		//BitString secondSource = mIR.substring(11, 5);
		//BitString destSource = mIR.substring(16, 5);
		mRegisters[31] = mPC;
		mPC.setValue(mRegisters[firstSource.getValue()].getValue());
		
	}
	
	
	/** Execute BEQ instruction that branches if the two registers are equal.
	 * 
	 */
	public void executeBEQ() {
        BitString firstSourceBS = mIR.substring(6, 5);

        BitString secondSourceBS = mIR.substring(11, 5);
        BitString immediate = mIR.substring(16, 16); // immediate value

        if (mRegisters[firstSourceBS.getValue()].getValue() == mRegisters[secondSourceBS.getValue()].getValue()) {
        	int temp = mPC.getValue() + 1 + immediate.getValue(); // checked. 
        	mPC.setValue(temp);
        }
	}
	
	
	/** Execute BNE instruction that branches if the two registers are not equal.
	 * 
	 */
	public void executeBNE() {
        BitString firstSourceBS = mIR.substring(6, 5);

        BitString secondSourceBS = mIR.substring(11, 5);
        BitString immediate = mIR.substring(16, 16); // immediate value

        if (mRegisters[firstSourceBS.getValue()].getValue() != mRegisters[secondSourceBS.getValue()].getValue()) {
        	int temp = mPC.getValue() + 1 + immediate.getValue();
        	mPC.setValue(temp);
        }
	}
	
	/**
	 * This method will execute all the instructions starting at address 0 
	 * till HALT instruction is encountered. 
	 */
	public void execute() {
		BitString opCodeStr;
		int opCode;
		BitString functCodeStr;
		int functCode;
		while (mMemory[mPC.getValue()].getValue() != 0) {
			// Fetch the instruction
			mIR = mMemory[mPC.getValue()];
			mPC.addOne();

			opCodeStr = mIR.substring(0, 6);
			opCode = opCodeStr.getValue();
			functCodeStr = mIR.substring(26, 6);
			functCode = functCodeStr.getValue();
		
			whichInstruction(opCode, functCode);
			
		}
	}
	
	
	/** This method takes in the opCode and determines which instruction to execute.
	 *  @param opCode It determines which instruction should be executed
	 *  @param functCode It determines which R instructions should be executed
	 */
	private void whichInstruction(int opCode, int functCode) {	
		
		if (opCode == 0 && functCode == 32) { // R format
			executeADD();
		} else if (opCode == 0 && functCode == 33) {
			executeADDU();
		} else if (opCode == 0 && functCode == 36) {
			executeAND();
		} else if (opCode == 0 && functCode == 37) {
			executeOR();	
		} else if (opCode == 0 && functCode ==  8) {
			executeJR();
		}  else if (opCode == 8) {
			executeADDI();
		} else if (opCode == 9) {
			executeADDIU();
		} else if (opCode == 12) {
			executeANDI();
		} else if (opCode == 13) {
			executeORI();
		} else if (opCode == 35) {
			executeLW();
		} else if (opCode == 43) {
			executeSW();
		} else if (opCode == 4) {
			executeBEQ();
		} else if (opCode == 5) {
			executeBNE();
		} else if (opCode == 2) {
			executeJ();
		}
	}
	
	
	/** Getter method to get mPC from Computer.java.
	 *  @return mPC from Computer.java
	 */
	public BitString getmPC() {
		return mPC;
	}
	
	
	/** Getter method to get mIR from Computer.java.
	 *  @return mIR from Computer.java
	 */
	public BitString getmIR() {
		return mIR;
	}
	
	
	/** Getter method to get address from Computer.java.
	 *  @return mRegisters[source.getValue()] get the address from the register
	 */
	public BitString getAddress(BitString source) {
		return mRegisters[source.getValue()];
	}
	
	
	/** Getter method to get Memory from Computer.java.
	 *  return mMemory[source.getValue()] get the address from the memory
	 */
	public BitString getmMemory(BitString source) {
		return mMemory[source.getValue()];
	}
	
	/**
	 * 
	 * Displays the computer's state.
	 * @return mystring to display all registers
	 */
	public String displayRegisters() {
		
		String mystring = "";
		mystring = mystring + "\n" +" " + "PC " + mPC.display(true);
		mystring = mystring + "\n" +" " + "IR " + mPC.display(true);
		mystring = mystring + "\n" +" " + "CC " + mPC.display(true);
	//	System.out.print("\nPC ");
	//	mPC.display(true);
	//	System.out.print("   ");

	//	System.out.print("IR ");
	//	mPC.display(true);
	//	System.out.print("   ");

	//	System.out.print("CC ");
	//	mCC.display(true);
	//	System.out.println("   ");

		for (int i = 0; i < MAX_REGISTERS; i++) {
			if (i == 0) {
				mystring = mystring + "\n" +" " + "$zero ";
			//	System.out.printf("$zero ");
			}
			else if (i == 1) {
				mystring = mystring + "\n" +" " + "$at ";
			//	System.out.printf("$at ");
			}
			else if (i == 2 || i == 3) {
				int n = i - 2;
				mystring = mystring + "\n" +" " + "$v" + n + " ";
			//	System.out.printf("$v%d ", i - 2);
			}
			
			else if (i >= 4 && i <= 7) {
				int n = i - 4;
				mystring = mystring + "\n" +" " + "$a" + n + " ";
				//System.out.printf("$a%d ", i - 4);
			}
						
			else if (i >= 8 && i <= 15) {
				int n = i - 8;
				mystring = mystring + "\n" +" " + "$t" + n + " ";
				//System.out.printf("$t%d ", i - 8);
			}

			
			else if (i >= 16 && i <= 27) {
				int n = i - 16;
				mystring = mystring + "\n" +" " + "$s" + n + " ";
			//	System.out.printf("$s%d ", i - 16);
				
			}
			
			else if (i == 28) {
				mystring = mystring + "\n" +" " + "$gp ";
				//System.out.printf("$gp ");
			}
			
			else if (i == 29) {
				mystring = mystring + "\n" +" " + "$sp ";
		//		System.out.printf("$sp ");
			}
			
			else if (i == 30) {
				mystring = mystring + "\n" +" " + "$fp ";
			//	System.out.printf("$fp ");
			}
			
			else if (i == 31){
				mystring = mystring + "\n" +" " + "$ra ";
			//	System.out.printf("$ra ");
			}
			mystring = mystring + mRegisters[i].display(true);
			//mRegisters[i].display(true);
			if (i % 3 == 2) {
			//	System.out.println();
			} else {
			//	System.out.print("   ");
			}
		}
//		System.out.println();
		return mystring;
	}
	
	/** Display status of memory.
	 *  @return mystring display all memory
	 */
	public String displayMemory() {
		String mystring = "";
		for (int i = 0; i < MAX_MEMORY; i++) {
			//System.out.printf("%3d ", i);
			mystring = mystring + "\n" +" " + i +" " + mMemory[i].display(true);
//			if (i % 3 == 2) {
//				System.out.println();
//			} else {
//				System.out.print("   ");
//			}
		}
//		System.out.println();
	return mystring;

	}
	
	
	/**
	 *  Getter method to get V0 from register as return.
	 *  @return a value for v0
	 */
	public String getv0() {
		return Integer.toString(mRegisters[2].getValue());
	}
	
	
	/**
	 *  Getter method to get V1 from register as return.
	 *  @return a value for v1
	 */
	public String getv1() {
		return Integer.toString(mRegisters[3].getValue());
	}
	
}
