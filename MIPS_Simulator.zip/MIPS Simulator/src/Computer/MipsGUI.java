package Computer;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import BitString.BitString;


/**
 * MipsGUI class helps to display graphical user interface. Users can input their assembly language using certain format 
 * to run their code and get the result.
 * 
 * @author Dung Thai
 * @author Ai Nguyen
 * @author Jiarui Xiong
 * @version 11-15-2019
 *
 */

public class MipsGUI extends JFrame implements ActionListener {
	
    /** 
	 *  Generated random ID.
	 */
	private static final long serialVersionUID = 1L;

	/** text area variable.
     */
    private JTextArea myRegisters;
    
    /** text area variable.
     */
    private JTextArea myMemory;
    
    /** text area variable.
     */
    private JTextArea myTextInput;
    
    /** text area variable.
     */
    private JTextArea myOutput;
    
    /** the execute button.
     */
    private JButton myExecuteButton;
    
    private ArrayList<String> Rinstructions;
    
    private ArrayList<String> Iinstructions;
    
    private ArrayList<BitString> bitstringInstructions;
    
    private HashMap<String, Integer> labelIndex;
    
    private Computer comp;

	public MipsGUI() {
		super("MIPS Simulator");
        //setExtendedState(JFrame.MAXIMIZED_BOTH);
		initGUI();
		Rinstructions = new ArrayList<>();
		Rinstructions.add("ADD");
		Rinstructions.add("ADDU");
		Rinstructions.add("AND");
		Rinstructions.add("OR");
		Rinstructions.add("JR");
		Iinstructions = new ArrayList<>();
		Iinstructions.add("ADDI");
		Iinstructions.add("ADDIU");
		Iinstructions.add("ANDI");
		Iinstructions.add("ORI");
		Iinstructions.add("LW");
		Iinstructions.add("SW");
		Iinstructions.add("BEQ");
		Iinstructions.add("BNE");
		setVisible(true);
	}

	private void initGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		 final JMenuBar menuBar = new JMenuBar();
	        menuBar.add(helpMenu());

	        this.setJMenuBar(menuBar); 
		
		// Contains Memory and registers.
        final Container regmemPanel = new JPanel(new BorderLayout());
        regmemPanel.add(registers(), BorderLayout.NORTH);
        regmemPanel.add(memory(), BorderLayout.SOUTH);
        
        add(instructions(), BorderLayout.CENTER);
        add(mipsBottom(), BorderLayout.SOUTH);
        add(regmemPanel, BorderLayout.EAST);
     
       pack();
	}
	
    private JMenu helpMenu() {
        final JMenu help = new JMenu("Help");
        JMenuItem Instructions = new JMenuItem("Instructions");
        Instructions.setEnabled(true);
        Instructions.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent theEvent) {
            	
//        		Rinstructions.add("ADD");
//        		Rinstructions.add("ADDU");
//        		Rinstructions.add("AND");
//        		Rinstructions.add("OR");
//        		Rinstructions.add("JR");
//        		Iinstructions = new ArrayList<>();
//        		Iinstructions.add("ADDI");
//        		Iinstructions.add("ADDIU");
//        		Iinstructions.add("ORI");
//        		Iinstructions.add("LW");
//        		Iinstructions.add("SW");
//        		Iinstructions.add("BEQ");
//        		Iinstructions.add("BNE");
            	
                final String aboutString = "Instructions must be put in correct format: \n R-type instructions: ADD, ADDU, AND, OR, JR \n Example: "
                		+ " \n ADD $s0 $t0 $s1 \n AND $t1 $s2 $t2 \n \n I-type instructions: ADDI, ADDIU, ORI, LW, SW, BEQ, BNE \n Example: \n "
                		+ "ADDI $s2 $t1 -7 \n LW $sp 8($sp) \n Jump Instruction: \n Example: \n J label \n \n Sample snippet:  \nMain:\nADDI $t1 $zero 1\n"
                		+ "ADDI $t0 $zero 11\nBNE $t1 $t0 ONE\nADD $v0 $t1 $zero\nONE:\nADD $v0 $t1 $t0";
                JOptionPane.showMessageDialog(null, aboutString, "How to input correct format",
                                  JOptionPane.INFORMATION_MESSAGE);
            }
        });
        help.add(Instructions);

        return help;
    }

	private JPanel memory() {
		 final JPanel memorypanel = new JPanel(new BorderLayout());
		 final JLabel memorylabel = new JLabel("Memory");
		 myMemory = new JTextArea(10, 30);
		 final JScrollPane memoryPane = new JScrollPane(myMemory);
		 memorypanel.add(memorylabel, BorderLayout.NORTH);
		 memorypanel.add(memoryPane, BorderLayout.CENTER);
		 memoryPane.setHorizontalScrollBar(null);
	      
		 myMemory.setEditable(false);
	        return memorypanel;
	}

	private JPanel registers() {
		 final JPanel registerpanel = new JPanel(new BorderLayout());
		 final JLabel registerlabel = new JLabel("Registers");
		 myRegisters = new JTextArea(10, 30);
		 final JScrollPane registerPane = new JScrollPane(myRegisters);
		 registerpanel.add(registerlabel, BorderLayout.NORTH);
		 registerpanel.add(registerPane, BorderLayout.CENTER);
		 registerPane.setHorizontalScrollBar(null);
 
		 myRegisters.setEditable(false);
	        return registerpanel;
	}

	private JPanel mipsBottom() {
		final JPanel bottomPanel = new JPanel(new BorderLayout());
		 final JLabel instructionlabel = new JLabel("Output");
		 myOutput = new JTextArea(10, 30);
		 final JScrollPane instructionPane = new JScrollPane(myOutput);
		 myExecuteButton = new JButton("Run Code");
		 
		 myExecuteButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				comp = new Computer();
				String textareastring = myTextInput.getText();
				Scanner getlabels = new Scanner(textareastring);
				myMemory.setText("");
				myRegisters.setText("");
				myOutput.setText("");
				labelIndex = new HashMap<>();
				int mapindex = 0;
				while (getlabels.hasNextLine()) {
					String[] parse = getlabels.nextLine().split(" ");
					if(parse[0].equals("J")) {
						if (parse[1].contains(":")) {
							labelIndex.put(parse[1].substring(0, parse[1].length()-1), mapindex); // only catch the keyword without ":" if it has.
						}
						else {
							labelIndex.put(parse[1], mapindex); // catch the keyword.
						}
						
					}
					if(parse.length < 2) {
						if (parse[0].contains(":")) {
							labelIndex.put(parse[0].substring(0,parse[0].length()-1), mapindex); // only catch the keyword without ":" if it has.
						}
						else {
							labelIndex.put(parse[0], mapindex); // catch the keyword.
						}
						
						
					}
					mapindex++;
				}
				Scanner s = new Scanner(textareastring);
				int counterforindex = 0;
				bitstringInstructions = new ArrayList<BitString>();
				while(s.hasNextLine()) {
					String line = s.nextLine();
					String[] parse = line.split(" ");

//					String[] parse = s.nextLine().split(" "); //check test case
					BitString inst = new BitString();
					inst.setValue(0);
					inst = inst.substring(0, 1);
					if (Rinstructions.contains(parse[0])) {
						BitString temp = getop(parse[0]);
						//inst = inst.append(temp);
						BitString op = new BitString();
						op.setValue(0);
						inst = inst.append(op.substring(0, 6));
						BitString temp1 = getreg(parse[1]);

						if (parse[0].equals("JR")) {
							inst = inst.append(temp1);
							inst = inst.append(op.substring(0, 15));
							inst = inst.substring(1, inst.getLength()-1);
							inst = inst.append(temp);
						}else {
							BitString temp2 = getreg(parse[2]);
							BitString temp3 = getreg(parse[3]);
							inst = inst.append(temp2);
							inst = inst.append(temp3);
							inst = inst.append(temp1);
							inst = inst.substring(1, inst.getLength()-1);
							BitString shamt = new BitString();
							shamt.setValue(0);
							inst = inst.append(shamt.substring(0, 5));
							inst = inst.append(temp);
						}
					}
					else if (Iinstructions.contains(parse[0])) {
						if(parse[0].equals("LW") || parse[0].equals("SW")) {
							BitString temp = getop(parse[0]);
							inst = inst.append(temp);
							inst = inst.substring(1, 6);
							String[] array3 = parse[2].split("\\(");
							if (array3.length >0) {
							BitString temp2 = getreg(array3[1].substring(0, 3));
							inst = inst.append(temp2);
							BitString temp1 = getreg(parse[1]);
							inst = inst.append(temp1);
							if(Integer.parseInt(array3[0]) < 0) {
								BitString temp3 = new BitString();
								temp3.setValue2sComp(Integer.parseInt(array3[0]));
								temp3 = temp3.substring(16, 16);
								inst = inst.append(temp3);	
							}else {
								BitString temp3 = new BitString();
								temp3.setValue(Integer.parseInt(array3[0]));
								temp3 = temp3.substring(16, 16);
								inst = inst.append(temp3);
							}
						} else {
							int index = labelIndex.get(parse[3]) - 1 - counterforindex;
							BitString instruction = new BitString();
							instruction.setValue(index);
							instruction = instruction.substring(16, 16);
							inst = inst.append(instruction);
							
						}
							}else if(parse[0].equals("BNE") || parse[0].equals("BEQ")){

							BitString temp = getop(parse[0]);

							inst = inst.append(temp);
							inst = inst.substring(1, 6);
							BitString temp1 = getreg(parse[1]);
							BitString temp2 = getreg(parse[2]);
							inst = inst.append(temp2);
							inst = inst.append(temp1);
														
//							System.out.println("RS1: "+ temp2.display(true));
//							System.out.println("RS2: "+ temp1.display(true));
//							System.out.println(parse[3]);
//							String key = parse[3];							
//							System.out.println("Index: "+index);
							String key = parse[3];
							if(!labelIndex.containsKey(key)) {     //??
								throw new IllegalArgumentException();
							}
//							int index = labelIndex.get(parse[3]) - 1 - counterforindex; 
							int index = labelIndex.get(key) - 1 - counterforindex; 
							BitString instruction = new BitString();
							instruction.setValue(index);
							instruction = instruction.substring(16, 16);
							inst = inst.append(instruction);
							System.out.println(inst.display(true));
						} else {
							BitString temp = getop(parse[0]);
							inst = inst.append(temp);
							inst = inst.substring(1, 6);
							BitString temp2 = getreg(parse[2]);
							inst = inst.append(temp2);
							BitString temp1 = getreg(parse[1]);
							inst = inst.append(temp1);
							if(Integer.parseInt(parse[3]) < 0) {
								BitString temp3 = new BitString();
								temp3.setValue2sComp(Integer.parseInt(parse[3]));
								temp3 = temp3.substring(16, 16);
								inst = inst.append(temp3);	
							}else {
								BitString temp3 = new BitString();
								temp3.setValue(Integer.parseInt(parse[3]));
								temp3 = temp3.substring(16, 16);
								inst = inst.append(temp3);
							}
						}
					}
					else if(parse[0].equals("J")) {
						String key = parse[0];
//						System.out.println(parse[0].toString());
						BitString temp = getop(key);
						
//						BitString temp = getop(parse[0]);
						inst = inst.append(temp);
						inst = inst.substring(1, 6);
//						System.out.println(inst.display(true));
						int index = labelIndex.get(parse[1]);
//						System.out.println("Index: "+index);
						BitString instruction = new BitString();
						instruction.setValue(index);
						instruction = instruction.substring(6, 26);
						inst = inst.append(instruction);
//						System.out.println("THE whole J: "+inst.display(true));
					}
//					else {
//						if(!labelIndex.containsKey(parse[0])) {     //??
//							throw new IllegalArgumentException();
//						}
//					}
					if(!labelIndex.containsKey(parse[0])) {
						bitstringInstructions.add(inst);
					}
					if (inst.getValue() == 0) {
						inst.setValue(0);
					}
					comp.loadWord(counterforindex, inst);
					comp.execute();
//					System.out.println(labelIndex.toString());
					counterforindex++;
				}
				
				
				for(BitString bits : bitstringInstructions) {
					System.out.println(bits.getBits());
				}
				//comp.execute();
				String mymemorystring = comp.displayMemory();
				myMemory.append(mymemorystring);
				String myregisterstring = comp.displayRegisters();
				myRegisters.append(myregisterstring);
				comp.displayRegisters();
				
				String getv0 = comp.getv0();
				String getv1 = comp.getv1();
				myOutput.append("Return Value v0: " + getv0 +"\n Return Value v1: " +getv1);
			}
		 });
		
		 
		 
		 bottomPanel.add(instructionlabel, BorderLayout.NORTH);
		 bottomPanel.add(instructionPane, BorderLayout.CENTER);
		 bottomPanel.add(myExecuteButton, BorderLayout.EAST);
		 instructionPane.setHorizontalScrollBar(null);
	      
		 myOutput.setEditable(false);
		
		return bottomPanel;
	}



	protected BitString getreg(String string) {
		BitString regvalue = new BitString();
		if(string.equals("$zero")) {
			regvalue.setValue(0);
		}
		else if(string.equals("$at")) {
			regvalue.setValue(1);
		}
		else if(string.equals("$v0")) {
			regvalue.setValue(2);
		}
		else if(string.equals("$v1")) {
			regvalue.setValue(3);
		}
		else if(string.equals("$a0")) {
			regvalue.setValue(4);
		}
		else if(string.equals("$a1")) {
			regvalue.setValue(5);
		}
		else if(string.equals("$a2")) {
			regvalue.setValue(6);
		}
		else if(string.equals("$a3")) {
			regvalue.setValue(7);
		}
		else if(string.equals("$t0")) {
			regvalue.setValue(8);
		}
		else if(string.equals("$t1")) {
			regvalue.setValue(9);
		}
		else if(string.equals("$t2")) {
			regvalue.setValue(10);
		}
		else if(string.equals("$t3")) {
			regvalue.setValue(11);
		}
		else if(string.equals("$t4")) {
			regvalue.setValue(12);
		}
		else if(string.equals("$t5")) {
			regvalue.setValue(13);
		}
		else if(string.equals("$t6")) {
			regvalue.setValue(14);
		}
		else if(string.equals("$t7")) {
			regvalue.setValue(15);
		}
		else if(string.equals("$s0")) {
			regvalue.setValue(16);
		}
		else if(string.equals("$s1")) {
			regvalue.setValue(17);
		}
		else if(string.equals("$s2")) {
			regvalue.setValue(18);
		}
		else if(string.equals("$s3")) {
			regvalue.setValue(19);
		}
		else if(string.equals("$s4")) {
			regvalue.setValue(20);
		}
		else if(string.equals("$s5")) {
			regvalue.setValue(21);
		}
		else if(string.equals("$s6")) {
			regvalue.setValue(22);
		}
		else if(string.equals("$s7")) {
			regvalue.setValue(23);
		}
		else if(string.equals("$t8")) {
			regvalue.setValue(24);
		}
		else if(string.equals("$t9")) {
			regvalue.setValue(25);
		}
		else if(string.equals("$k0")) {
			regvalue.setValue(26);
		}
		else if(string.equals("$k1")) {
			regvalue.setValue(27);
		}
		else if(string.equals("$gp")) {
			regvalue.setValue(28);
		}
		else if(string.equals("$sp")) {
			regvalue.setValue(29);
		}
		else if(string.equals("$fp")) {
			regvalue.setValue(30);
		}
		else if(string.equals("$ra")) {
			regvalue.setValue(31);
		}else {
			throw new IllegalArgumentException();
		}
		return regvalue.substring(27, 5);
	}

	protected BitString getop(String string) {
		BitString  opcode = new BitString();
		if(string.equals("ADD")) {
			opcode.setValue(32);
		}
		if(string.equals("ADDU")) {
			opcode.setValue(33);
		}		
		if(string.equals("AND")) {
			opcode.setValue(36);
		}
		if(string.equals("OR")) {
			opcode.setValue(37);
		}
		if(string.equals("ADDI")) {
			opcode.setValue(8);
		}
		if(string.equals("ADDIU")) {
			opcode.setValue(9);
		}
		if(string.equals("ORI")) {
			opcode.setValue(13);
		}
		if (string.equals("ANDI")) {
			opcode.setValue(12);
		}
		if(string.equals("LW")) {
			opcode.setValue(35);
		}
		if(string.equals("SW")) {
			opcode.setValue(43);
		}
		if(string.equals("BEQ")) {
			opcode.setValue(4);
		}
		if(string.equals("BNE")) {
			opcode.setValue(5);
		}
		if(string.equals("J")) {
			opcode.setValue(2);
		}
		if(string.equals("JR")) {
			opcode.setValue(8);
		}
		
		return opcode.substring(26, 6);
	}

	private JPanel instructions() {
		 final JPanel instructionpanel = new JPanel(new BorderLayout());
		 final JLabel instructionlabel = new JLabel("Enter Codes Here");
		 myTextInput = new JTextArea(10, 30);
		 final JScrollPane instructionPane = new JScrollPane(myTextInput);
		 instructionpanel.add(instructionlabel, BorderLayout.NORTH);
		 instructionpanel.add(instructionPane, BorderLayout.CENTER);
		 instructionPane.setHorizontalScrollBar(null);
	      
		 myTextInput.setEditable(true);
	        return instructionpanel;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}
}
