package Junit;
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import BitString.BitString;


/**
 * MipsGUI class helps to display graphical user interface. Users can input their assembly language using certain format 
 * to run their code and get the result.
 * @author mmuppa
 * @author Dung Thai
 * @author Ai Nguyen
 * @author Jiarui Xiong
 * @version 11-15-2019
 *
 */


public class BitStringTest {

	/**
	 *  Set up.
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	
	/**
	 *  test BitString's constructor.
	 * 
	 */
	@Test
	public void testBitStringConstructor() {
		BitString bitString = new BitString();
		assertNotNull(bitString);
		assertEquals(bitString.getLength(), 0);
		assertArrayEquals(bitString.getBits(), null);
	}
	
	

	/**
	 * Test setBits Method. If set Bits with over length, it will throw an exception.
	 */
	@Test(expected = IllegalArgumentException.class)
	public void testSetBitsOverLength() {
		BitString bitString = new BitString();
		bitString.setBits(new char[30]);
	}
	
	/**
	 * setBits method, if null, it will throw an exception.
	 */
	@Test(expected = IllegalArgumentException.class)
	public void testSetBitsNull() {
		BitString bitString = new BitString();
		char[] temp = null;
		bitString.setBits(temp);
	}

	/**
	 * Test setBits method. Check if set Bits into BitString correctly.
	 */
	@Test
	public void testSetBits() {
		BitString bitString = new BitString();
		char test[] = { '1', '0', '1', '0' };
		bitString.setBits(test);
		assertEquals(bitString.getLength(), 4);
		assertArrayEquals(bitString.getBits(), test);
	}

	
	/**
	 *  Test invert method if null, it will throw illegal argument exception. 
	 */	
	@Test(expected = IllegalArgumentException.class)
	public void testInvertNull() {
		BitString bitString = new BitString();
		char[] temp = {};
		bitString.setBits(temp);
		bitString.invert();
	}
	
	
	/**
	 *  Test invert metho if invalid input, it will catch illegal argument exception.
	 */
	@Test
	public void testInvertInvalid() {

		BitString bitString = new BitString();		
		char[] temp = null;
		try {

			bitString.setBits(temp);
			fail("Can set negative value for unsigned");
		} catch (IllegalArgumentException e) {

		}
	}
	
	
	/**
	 *  Test invert method, it will pass a BitString and invert it. 
	 */
	@Test
	public void testInvert() {
		char allOnes[] = { '1', '1', '1', '1' };
		char allZeros[] = { '0', '0', '0', '0' };
		BitString bitString = new BitString();
		bitString.setBits(allZeros);
		bitString.invert();
		assertArrayEquals(bitString.getBits(), allOnes);
		bitString.invert();
		assertArrayEquals(bitString.getBits(), allZeros);
	}
	
	
	/**
	 *  Test ADD one method. It will pass a BitString and the BitString will add one. 
	 */

	@Test
	public void testAddOne() {
		char allZeros[] = { '0', '0', '0', '0' };
		char one[] = { '0', '0', '0', '1' };
		char two[] = { '0', '0', '1', '0' };
		char allOnes[] = { '1', '1', '1', '1' };
		BitString bitString = new BitString();
		bitString.setBits(allZeros);
		bitString.addOne();
		assertArrayEquals(bitString.getBits(), one);
		bitString.setBits(allOnes);
		bitString.addOne();
		assertArrayEquals(bitString.getBits(), allZeros);
		bitString.setBits(one);
		bitString.addOne();
		assertArrayEquals(bitString.getBits(), two);
	}
	
	
	/**
	 *  Test set Value. If passing an invalid value, it will catch an illegal exception.
	 */

	@Test
	public void testSetValueInvalid() {

		BitString bitString = new BitString();
		try {
			bitString.setValue(-10);
			fail("Can set negative value for unsigned");
		} catch (IllegalArgumentException e) {

		}
		try {
			bitString.setValue(65536);
			fail("Can set more than max for unsigned");
		} catch (IllegalArgumentException e) {

		}

	}

	
	/**
	 *  Test set Value, If passing a value, it will convert to 10 in BitString.
	 */
	@Test
	public void testSetValue() {
		char ten[] = { '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0',
				'0', '1', '0', '1', '0' };

		BitString bitString = new BitString();
		bitString.setValue(10);
		assertArrayEquals(bitString.substring(16,16).getBits(), ten);
	}
	
	

	
	/**
	 *  Test set Value 2's complement. If passing a signed value, it will convert to BitString with 2's complement.
	 */
	@Test
	public void testSetValue2sComp() {
		char max[] = { '0', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1',
				'1', '1', '1', '1', '1' };
		char min[] = { '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0',
				'0', '0', '0', '0', '0' };
		BitString bitString = new BitString();
		bitString.setValue2sComp(32767);
		assertArrayEquals(max,bitString.substring(16, 16).getBits());
		bitString.setValue2sComp(-32768);
		assertArrayEquals(min, bitString.substring(16,16).getBits());
	}

	
	/**
	 *  Test set Value 2's complement. If passing an invalid signed value, it will catch an exception.
	 */
	@Test
	public void testSetValue2sCompInvalid() {
		BitString bitString = new BitString();
		try {
			bitString.setValue2sComp(-32769);
			fail("Can set negative value for 2s comp");
		} catch (IllegalArgumentException e) {

		}
		try {
			bitString.setValue2sComp(32768);
			fail("Can set more than max for 2s comp");
		} catch (IllegalArgumentException e) {

		}
	}
	

	/**
	 *  Test get value. Get the decimal value from BitString. 
	 */
	@Test
	public void testGetValue() {
		char ten[] = { '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0',
				'0', '1', '0', '1', '0' };
		BitString bitString = new BitString();
		bitString.setBits(ten);
		assertEquals(bitString.getValue(), 10);

	}
	

	/** 
	 *  Test get 2's complement value. Passing a BitString and convert to a signed number.
	 */
	@Test
	public void testGetValue2sComp() {
		char ones[] = { '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1',
				'1', '1', '1', '1', '1' };
		char min[] = { '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0',
				'0', '0', '0', '0', '0' };
		BitString bitString = new BitString();
		bitString.setBits(ones);
		assertEquals(bitString.getValue2sComp(), -1);
		bitString.setBits(min);
		assertEquals(bitString.getValue2sComp(), -32768);
	}
	
	
	/**
	 *  Test append method, it will combine two valid BitStrings into a new valid BitString.
	 */
	
	@Test
	public void testAppend() {
		char fourBits[] = { '0', '0', '0', '0' };
		char eightBits[] = { '1', '0', '0', '0', '0', '0', '0', '0' };
		char twelveBits[] = { '0', '0', '0', '0', '1', '0', '0', '0', '0', '0',
				'0', '0' };
		BitString bitString = new BitString();
		bitString.setBits(fourBits);
		bitString.display(true);
		BitString anotherBitString = new BitString();
		anotherBitString.setBits(eightBits);
		BitString appendedString = bitString.append(anotherBitString);
		appendedString.display(true);
		assertArrayEquals(appendedString.getBits(), twelveBits);
	}
	
	


	/**
	 *  Test substring method. Passing the starting point and length of the BitString. 
	 *  It will compare a target and passed BitString.
	 */
	@Test
	public void testSubstring() {
		char twelveBits[] = { '0', '0', '0', '0', '1', '0', '0', '0', '0', '0',
				'0', '0' };
		char eightBits[] = { '1', '0', '0', '0', '0', '0', '0', '0' };
		BitString bitString = new BitString();
		bitString.setBits(twelveBits);
		BitString partString = bitString.substring(4, 8);
		assertArrayEquals(partString.getBits(), eightBits);
	}
}
