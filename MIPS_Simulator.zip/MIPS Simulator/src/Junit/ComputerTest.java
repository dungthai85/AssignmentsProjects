package Junit;


import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import BitString.BitString;
import Computer.Computer;

import static org.junit.Assert.*;


import static org.junit.jupiter.api.Assertions.assertEquals;



/**
 * 
 * 
 * 
 * @author Dung Thai
 * @author Ai Nguyen
 * @author Jiarui Xiong
 * @version 11-15-2019
 *
 */

public class ComputerTest {

	/**
	 * Test the Add instruction 
	 * adding two positive values together
	 * $t0 = $s1 + $s2s
	 */
	@Test
	public void testExecuteAddPositive() { //ADD $t0, $s1, $s2
		Computer comp = new Computer();
		
		comp.getmIR().setBits("00000010001100100100000000100000".toCharArray()); 
		comp.executeADD();
		assertEquals(35, comp.getAddress(comp.getmIR().substring(16, 5)).getValue());
	}
	
	/**
	 * Test the Add instruction.
	 * The opcode add if correct or incorrect.
	 * 
	 */
	
	@Test
	public void testOpCodeADD() {
		Computer comp = new Computer();
		BitString test = new BitString();
		test.setBits("00000010001100100100000000100000".toCharArray());
		comp.loadWord(0, test);
		comp.getmIR().setBits("00000010001100100100000000100000".toCharArray()); 
		comp.execute();
		assertEquals(35, comp.getAddress(comp.getmIR().substring(16, 5)).getValue());
	}
	
//	@Test(expected = IllegalArgumentException.class)
//	void testLoadIntoMem() {
//		Computer comp = new Computer();
//		BitString test = new BitString();
//		test.setBits("00000000000000000000000000011000".toCharArray()); // 24
//		comp.loadWord(-1, test);
//		
//	}
	
	/**
	 * Test the Add instruction.
	 * adding a positive value and a negative value.
	 * $t0 = $s1 + $s2s.
	 */
	@Test
	public void testExecuteAddNegative() {
		Computer comp = new Computer();
		comp.getmIR().setBits("00000010001100100100000000100000".toCharArray()); 
		
		BitString firstSource = comp.getmIR().substring(6, 5);
		comp.getAddress(firstSource).setBits("1101".toCharArray());
		
		BitString secondSource = comp.getmIR().substring(11, 5);
		comp.getAddress(secondSource).setBits("0100".toCharArray());
		
		comp.executeADD();
		assertEquals(1, comp.getAddress(comp.getmIR().substring(16, 5)).getValue());
	}
	/**
	 * Test the Add instruction
	 * adding two negative values together
	 * $t0 = $s1 + $s2s.
	 */
	@Test
	public void testExecuteAddNegativeResult() {
		Computer comp = new Computer();
		comp.getmIR().setBits("00000010001100100100000000100000".toCharArray()); 
		
		BitString firstSource = comp.getmIR().substring(6, 5);
		comp.getAddress(firstSource).setBits("1101".toCharArray());
		
		BitString secondSource = comp.getmIR().substring(11, 5);
		comp.getAddress(secondSource).setBits("1101".toCharArray());
		
		comp.executeADD();
		assertEquals(-6, comp.getAddress(comp.getmIR().substring(16, 5)).getValue());
	}
	
	/**
	 * Testing ADDU. and compare with target.
	 */
	@Test 
	public void testExecuteADDU() { 
		Computer comp = new Computer();
		comp.getmIR().setBits("00000010001100100100000000100001".toCharArray()); 
		comp.executeADDU();
		assertEquals(35, comp.getAddress(comp.getmIR().substring(16, 5)).getValue());
	}
	
	/**
	 * Testing opcode for ADDU, and compare a opcode from BitString and actual opcode for ADDU.
	 */
	@Test
	public void testOpCodeADDU() {
		Computer comp = new Computer();
		BitString test = new BitString();
		test.setBits("00000010001100100100000000100001".toCharArray());
		comp.loadWord(0, test);
		comp.getmIR().setBits("00000010001100100100000000100001".toCharArray()); 
		comp.execute();
		assertEquals(35, comp.getAddress(comp.getmIR().substring(16, 5)).getValue());
	}
	
	/**
	 * Testing AND. Execute AND and compare with a target.
	 */
	@Test
	public void testExecuteAND() { //AND $t0, $s1, $s2
		Computer comp = new Computer();
		comp.getmIR().setBits("00000010001100100100000000100100".toCharArray()); 
		BitString firstSource = comp.getmIR().substring(6, 5);
		comp.getAddress(firstSource).setBits("11010".toCharArray());
		
		BitString secondSource = comp.getmIR().substring(11, 5);
		comp.getAddress(secondSource).setBits("11011".toCharArray());
		comp.executeAND();
		
		BitString test = new BitString();
		test.setBits("11010".toCharArray());
		assertEquals(test.getValue(), comp.getAddress(comp.getmIR().substring(16, 5)).getValue());
	}

	/**
	 * Testing OR, Execute OR and compare with a target.
	 */
	@Test
	public void testExecuteOR() {
		Computer comp = new Computer();
		comp.getmIR().setBits("00000010001100100100000000100101".toCharArray()); 
		BitString firstSource = comp.getmIR().substring(6, 5);
		comp.getAddress(firstSource).setBits("11010".toCharArray());
		
		BitString secondSource = comp.getmIR().substring(11, 5);
		comp.getAddress(secondSource).setBits("11011".toCharArray());
		comp.executeOR();
		
		BitString test = new BitString();
		test.setBits("11011".toCharArray());
		
		assertEquals(test.getValue(), comp.getAddress(comp.getmIR().substring(16, 5)).getValue());

	}
	
	
	/**
	 * Testing ADDI, Execute ADD using a negative number and compare with a target.
	 */
	@Test
	public void testExecuteADDINegavtive() {// ADDI $s2, $s1, -1
		Computer comp = new Computer();
		comp.getmIR().setBits("00100010001100101111111111111111".toCharArray());
		comp.executeADDI();
		assertEquals(16, comp.getAddress(comp.getmIR().substring(11, 5)).getValue());
		
	}
	
	
	/**
	 * Testing ADDI, Execute ADD using a positive number and compare with a target.
	 */
	@Test
	public void testExecuteADDIPositive() { // ADDI $s2, $s1, 8
		Computer comp = new Computer();
		comp.getmIR().setBits("00100010001100100000000000001000".toCharArray());
		comp.executeADDI();
		assertEquals(25, comp.getAddress(comp.getmIR().substring(11, 5)).getValue());
		
	}
	
	/**
	 *  Testing ADDIU, compare a target and a value from BitString.
	 */
	@Test
	public void testExecuteADDIU() { // ADDIU $s2, $s1, 8
		Computer comp = new Computer();
		comp.getmIR().setBits("00100010001100100000000000001000".toCharArray());
		comp.executeADDIU();
		assertEquals(25, comp.getAddress(comp.getmIR().substring(11, 5)).getValue());
		
	}
	
	
	/**
	 *  Testing ORI, compare a target.
	 */
	@Test
	public void testExecuteORI() { // ORI $s2, $s1, 8
		Computer comp = new Computer();
		comp.getmIR().setBits("00100010001100100000000000001000".toCharArray());
		comp.executeORI();
		BitString test = new BitString();
		test.setBits("11001".toCharArray());
		int temp = comp.getAddress(comp.getmIR().substring(11, 5)).getValue();
		assertEquals(test.getValue(), temp);
		
	}
	
	
	/**
	 *  Testing LW, compare with target.
	 */
	@Test
	public void testLW() { // LW $s3, 8($s0)
	    Computer comp = new Computer();
		BitString test = new BitString();
		test.setBits("00000000000000000000000000011000".toCharArray()); // 24
		
		comp.getmIR().setBits("10001110000100110000000000001000".toCharArray());
		comp.loadWord((18), test); 
		comp.executeLW();
		assertEquals(24, comp.getAddress(comp.getmIR().substring(11, 5)).getValue());
	}
	
	
	/**
	 *  Testing SW, compare with target.
	 */
	@Test
	public void testSW() { // LW $s3, 8($s0)
	    Computer comp = new Computer();	
		comp.getmIR().setBits("10101110000100110000000000001000".toCharArray());
		comp.executeSW();
		assertEquals(19, comp.getAddress(comp.getmIR().substring(11, 5)).getValue());
	}
	
	
	/**
	 *  Testing BEQ, compare with a target and check it jumps to expected address when two values are equal.
	 */
	@Test 
	public void testBEQ() { // beq $t0, $t1, skip
					 // skip with jump offset of 2 
		Computer comp = new Computer();	
		BitString test = new BitString();
		test.setBits("00010001000010010000000000000010".toCharArray()); // beq
		comp.getmIR().setBits("00010001000010010000000000000010".toCharArray());
		comp.loadWord(0, test);
		BitString firstSource = comp.getmIR().substring(6, 5);
		comp.getAddress(firstSource).setBits("11010".toCharArray());
		
		BitString secondSource = comp.getmIR().substring(11, 5);
		comp.getAddress(secondSource).setBits("11010".toCharArray());
		comp.executeBEQ();
		assertEquals(3, comp.getmPC().getValue());
	}
	
	
	/**
	 *  Testing BNE, compare with a target and check it jumps to expected address when two values are not equal.
	 */
	@Test 
	public void testBNE() { // bne $t0, $t1, skip
					 // skip with jump offset of 2 
		Computer comp = new Computer();	
		BitString test = new BitString();
		test.setBits("00010001000010010000000000000010".toCharArray()); // bne
		comp.getmIR().setBits("00010001000010010000000000000010".toCharArray());
		comp.loadWord(0, test);
		BitString firstSource = comp.getmIR().substring(6, 5);
		comp.getAddress(firstSource).setBits("11011".toCharArray());
		
		BitString secondSource = comp.getmIR().substring(11, 5);
		comp.getAddress(secondSource).setBits("11010".toCharArray());
		comp.executeBNE();
		assertEquals(3, comp.getmPC().getValue());
	}
	
	/** 
	 *  Testing J, compare with a target and check after calling J if jumps to expected address.
	 */
	@Test
	public void testJ() { // J
        // mPC.setValue(mRegisters[firstSource.getValue()].getValue());

        Computer comp = new Computer();
        BitString test = new BitString();
        test.setBits("000010000000000000000000000010".toCharArray());
        comp.getmIR().setBits("00001000000000000000000000000010".toCharArray());
        comp.loadWord(0, test);
        comp.loadWord(1, test);
        comp.loadWord(2, test);
        comp.executeJ();
        assertEquals(2, comp.getmPC().getValue()); 

    }
	
	@Test
	public void testJR() { // JR $v0 (index 2)
        // mPC.setValue(mRegisters[firstSource.getValue()].getValue());

        Computer comp = new Computer();
        BitString test = new BitString();
        test.setBits("00000000010000000000000000001000".toCharArray());
        comp.loadWord(0, test);
        comp.executeJR();
        comp.getAddress(test.substring(5, 6));
        assertEquals(2, comp.getAddress(test.substring(5, 6)).getValue());

    }
}
