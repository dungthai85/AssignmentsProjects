import java.awt.EventQueue;

import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import BitString.BitString;
import Computer.Computer;
import Computer.MipsGUI;


/**
 * 
 * 
 * 
 * @author Dung Thai
 * @author Ai Nguyen
 * @author Jiarui Xiong
 * @version 11-15-2019
 *
 */


public class Simulator {
	

	public static void main(String[] args) {
		
        try {
            //UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
//            UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
            UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
        } catch (final UnsupportedLookAndFeelException ex) {
            ex.printStackTrace();
        } catch (final IllegalAccessException ex) {
            ex.printStackTrace();
        } catch (final InstantiationException ex) {
            ex.printStackTrace();
        } catch (final ClassNotFoundException ex) {
            ex.printStackTrace();
        }
        /* Turn off metal's use of bold fonts */
        UIManager.put("swing.boldMetal", Boolean.FALSE);
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new MipsGUI();
            }
        });

        
//		Computer comp;

		/************************************** */
		/** The next two variables - program and programSize - */
		/** allow someone using the simulator (such as a grader) */
		/** to decide what program will be simulated. */
		/** The simulation must load and execute */
		/** instructions found in the "program" array. */
		/** For grading purposes, it must be possible for me to */
		/**
		 * - paste in a different set of binary strings to replace the existing
		 * ones
		 */
		/** - recompile your program without further changes */
		/** and see the simulator load and execute the new program. */
		/** Your grade will depend largely on how well that works. */
		/************************************** */

//		String program[] = { "0010000000000111", "0010001000000111",
//				"0001010000000001", "0000010000000011", "1111000000100001",
//				"0001000000111111", "0000111111111011", "1111000000100101",
//				"0000000000111001", "1111111111010000" };

		/*
		 * This is the assembly program that was compiled into the binary
		 * program shown above. 
		 * 		.ORIG x3000
		 * 
		 * 		LD R0 START 
		 * 		LD R1 END 
		 * TOP 	ADD R2 R0 R1 
		 * 		BRZ DONE 
		 * 		OUT 
		 * 		ADD R0 R0 -1
		 * 		BRNZP TOP 
		 * DONE HALT
		 * 
		 * START .FILL x39 
		 * END .FILL x-30
		 * 
		 * 		.END
		 */
//		comp = new Computer();
		//comp.display();

		/* TO DO: load the instructions in the "program" array */

		/* Next 3 lines are a test of NOT */
		/* Once you are confident that single instructions work, you will */
		/* want to replace this with code that loads all the instructions */
		/* from the array shown above. */
//		BitString notInstr = new BitString();
//		notInstr.setBits("10000010001100100100000000100000".toCharArray());
//		comp.loadWord(0, notInstr);
		
		
		//comp.executeADD();
		/* execute the program */
		/* During execution, the only output to the screen should be */
		/* the result of executing OUT. */
//		comp.execute();
		

		/* shows final configuration of computer */
		//comp.display();
	}

}
