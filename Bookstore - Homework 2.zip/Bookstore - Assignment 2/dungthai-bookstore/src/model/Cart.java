/*
 * TCSS 305 - Winter 2019
 * Assignment 2 - UW Bookstore
 */

package model;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 *  Stores information about the overall purchase. 
 *  Includes calculations for total.
 * @author DungThai
 * @version 25 Jan 2019
 */
public class Cart {
    
    /** initiate membership
     */
    private boolean myMembership;
    
    /** Initiate cart
     */
    private Set<ItemOrder> myCart;
    
    /**
     * this constructor creates and empty cart.
     */
    public Cart() {
        myCart = new HashSet<ItemOrder>();
    }

    /**
     * Adds order to cart, if the cart already contains the order, it will remove then add.
     * @param theOrder the order coming in.
     */
    public void add(final ItemOrder theOrder) {
        if(myCart.contains(theOrder)) {
            myCart.remove(theOrder);
        }
        myCart.add(theOrder);
    }

    /**
     *sets myMembership to true or false.
     * @param theMembership Once clicked will be true
     */
    public void setMembership(final boolean theMembership) {
            myMembership = theMembership;   
    }

    /**
     * Method returns total cost of shopping cart.
     * @return with a scale of 2 and ROUND_HALF_EVEN.
     */
    public BigDecimal calculateTotal() {
        BigDecimal totalPrice = BigDecimal.ZERO;
        Iterator<ItemOrder> setIterator = myCart.iterator();
        while (setIterator.hasNext()) {
            ItemOrder tempOrder = setIterator.next();
            Item tempItem = tempOrder.getItem();
            int itemQuantity = tempOrder.getQuantity();
            int bulkQuantity = tempItem.getBulkQuantity();
            int bulkQuantityTotal = 0;
            BigDecimal singlePrice = tempItem.getPrice();
            BigDecimal bulkPrice = tempItem.getBulkPrice();
            
            if(bulkQuantity > 0 && myMembership == true) {
                bulkQuantityTotal = itemQuantity/bulkQuantity;
                itemQuantity = itemQuantity%bulkQuantity;
            } else {
                bulkQuantity = 0;
            }
            BigDecimal intToBDBulk = new BigDecimal(bulkQuantityTotal);
            BigDecimal bulkPriceTotal = bulkPrice.multiply(intToBDBulk);
            BigDecimal intToBDPrice = new BigDecimal(itemQuantity);
            BigDecimal singlePriceTotal = singlePrice.multiply(intToBDPrice);
            totalPrice = totalPrice.add(singlePriceTotal.add(bulkPriceTotal));
        }
        return totalPrice.setScale(2, BigDecimal.ROUND_HALF_EVEN);
    }
    
    /** Clears cart when button is pushed.
     */
    public void clear() {
        myCart.clear();
    }

    /**
     * Override to set the final string needed for purchase.
     */
    @Override
    public String toString() {
        Iterator<ItemOrder> setIterator = myCart.iterator();
        String output = "";
        while (setIterator.hasNext()) {
            output = output+setIterator.next().toString();
        }
        return output;
    }

}
