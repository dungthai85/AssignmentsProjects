/*
 * TCSS 305 - Winter 2019
 * Assignment 2 - UW Bookstore
 */

package model;

import java.math.BigDecimal;
import java.util.Objects;

/**
 * This class shows the Items and Prices.
 * It stores them individually.
 * 
 * @author Dung Thai
 * @version 25 Jan 2019
 */
public final class Item {
 
    /** The name of the item.
     */
    private String myName;
    
    /** The price of the item.
     */
    private BigDecimal myPrice;
    
    /** The amount to be bulk quantity.
     */
    private int myBulkQuantity;
    
    /** The price in bulk.
     */
    private BigDecimal myBulkPrice;
    
    /**
     * Default Constructor for just the name and price.
     * @param theName is the string name of item.
     * @param thePrice BigDecimal price.
     */
    public Item(final String theName, final BigDecimal thePrice) {
        this(theName, thePrice, 0, BigDecimal.ZERO);
    }

    /**
     * The Constructor that checks for exceptions and sets value to initiated variables.
     * @param theName Name of item.
     * @param thePrice BigDecimal price
     * @param theBulkQuantity The amount to be bulk.
     * @param theBulkPrice The price if bulk.
     */
    public Item(final String theName, final BigDecimal thePrice, final int theBulkQuantity,
                final BigDecimal theBulkPrice) {
        
        /** String cannot be null.
         */
        if(theName == null) {
            throw new NullPointerException("Name Cannot Be Null");
        }
        
        /** String cannot be empty.
         */
        if(theName.equals("")) {
            throw new IllegalArgumentException("Name Cannot Be Empty");
        }
        
        myName = theName;
        
        /** Price cannot be null.
         */
        if(thePrice == null) {
            throw new NullPointerException("Price Cannot Be Null");
        }
        
        /** Price cannot equal zero.
         */
        if(thePrice == BigDecimal.ZERO) {
            throw new IllegalArgumentException("Price Cannot Be Zero");
        }
        
        /** Price cannot be less than zero.
         */
        if(thePrice.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Price Cannot Be Less Than Zero");
        }
        
        myPrice = thePrice;
        
        /** Bulk Quantity cannot be less than 0.
         */
        if(theBulkQuantity < 0) {
            throw new IllegalArgumentException("Quantity Cannot Be less than 0");
        }
        
        myBulkQuantity = theBulkQuantity;
        
        /** Bulk Price cannot be null.
         */
        if(theBulkPrice == null) {
            throw new NullPointerException("Price Cannot Be Null");
        }
        
        myBulkPrice = theBulkPrice;
       
    }

    /** Gets Price.
     */
    public final BigDecimal getPrice() {
        
        return myPrice;
    }
    
    /** Gets Bulk Quantity.
     */
    public final int getBulkQuantity() {
        
        return myBulkQuantity;
    }
    
    /** Gets Bulk Price.
     */
    public final BigDecimal getBulkPrice() {
        
        return myBulkPrice;
    }

    /**
     *  Checks if item is bulk.
     * @return false if item is not bulk.
     */
    public final boolean isBulk() {
        if(getBulkQuantity() > 0) {
            return true;
        }
        return false;
    }

    /**
     * This method overrides the toString Method 
     * Checks if there is a bulk order, if not it will just return name and price.
     */
    @Override
    public String toString() {
        String name = myName;
        String price = getPrice().toString();
        if(isBulk() == true) {
            String bulkAmount = String.valueOf(getBulkQuantity());
            String bulkPrice = getBulkPrice().toString();
            return name+", $"+price+" ("+bulkAmount+" for $"+bulkPrice+")";
        }
        return name+", $"+price;
    }

    /**
     * Equals method to check if the classes are equivalent.
     * @return true if they are equivalent.
     */
    @Override
    public boolean equals(final Object theOther) {
        final boolean result;
        if(theOther == null || this.getClass() != theOther.getClass()) {
            result = false;
        } else {
            final Item other = (Item) theOther;
            result = ((String) myName).equals(other.myName)
                            && myPrice.equals(other.myPrice)
                            && myBulkQuantity == other.myBulkQuantity
                            && myBulkPrice.equals(other.myBulkPrice);
        }
        return result;
    }

    /**
     * Override method is to save the hash code if it is consistent with equals.
     */
    @Override
    public final int hashCode() {
        return Objects.hash(myName, myPrice, myBulkQuantity, myBulkPrice);
    }

}
