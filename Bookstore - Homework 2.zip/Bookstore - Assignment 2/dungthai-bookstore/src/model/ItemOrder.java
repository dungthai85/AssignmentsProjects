/*
 * TCSS 305 - Winter 2019
 * Assignment 2 - UW Bookstore
 */

package model;

/**
 * This class stores information about purchase order
 * It references to the item itself.
 * @author Dung Thai
 * @version 25 Jan 2019
 */
public final class ItemOrder {
    
    /** Initiate Item.
     */
    private Item myItem;
    
    /** Initiate Quantity.
     */
    private int myQuantity;

    /** The  Constructor for Item Order
     * @param theItem name of the item
     * @param theQuantity amount of items.
     */
    public ItemOrder(final Item theItem, final int theQuantity) {
        myItem = theItem;
        myQuantity = theQuantity;

    }

    /** method to get item.
     */
    public final Item getItem() {
        
        return myItem;
    }
    
    /** Method to get quantity
     */
    public int getQuantity() {
        
        return myQuantity;
    }

    /**
     * Override to set representation of the order.
     */
    @Override
    public String toString() {
    
        return myItem.toString()+", "+String.valueOf(myQuantity);
    }
    
    /**
     * Override to check if items are equal.
     */
    @Override
    public final boolean equals(final Object theOther) {
        final boolean result;
        if(theOther == null || this.getClass() != theOther.getClass()) {
            result = false;
        } else {
            final ItemOrder other = (ItemOrder) theOther;
            result = other.getItem().equals(getItem());
        }
        return result;
    }
    
    /**
     * Override to get the item hash code.
     */
    @Override
    public int hashCode() {
        return myItem.hashCode();
    }

}
