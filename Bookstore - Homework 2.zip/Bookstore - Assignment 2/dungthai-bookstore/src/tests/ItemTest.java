/*
 * TCSS 305 - Winter 2019
 * Assignment 2 - UW Bookstore
 */

package tests;

import static org.junit.Assert.*;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;

import model.Item;

/**
 * This JUnit is to test the Item Class.
 * @author Dung Thai
 * @version 25 Jan 2019
 */
public class ItemTest {
    
    /** My test item for default Constructor
     */
    private Item myTwoItems;
    
    /** My main test object.
     */
    private Item myFourItems;

    /**
     * The default set up to start up after every method test.
     */
    @Before
    public void setUp() {
        myTwoItems = new Item("Test", BigDecimal.ONE);
        myFourItems = new Item("Hello", BigDecimal.TEN, 4, BigDecimal.ONE);
        
    }

    /** Testing hash code notEquals.
     */
    @Test
    public void testHashCodeNE() {
        assertNotEquals(myFourItems.hashCode(), myTwoItems.hashCode());
    }
    
    /** Testing hash code equals.
     */
    @Test
    public void testHashCodeEquals() {
        assertEquals(myFourItems.hashCode(), myFourItems.hashCode());
    }
    
    /** Testing String for Null Pointer.
     */
    @Test(expected = NullPointerException.class)
    public void testItemStringBigDecimalStringNull() {
        myFourItems = new Item(null, BigDecimal.TEN);
    }
    
    /** Testing String for Illegal Argument.
     */
    @Test(expected = IllegalArgumentException.class)
    public void testItemStringBigDecimalStringIE() {
        myFourItems = new Item("", BigDecimal.TEN);
    }
    
    /** Testing price for Null Pointer.
     */
    @Test(expected = NullPointerException.class)
    public void testItemStringBigDecimalNull() {
        myTwoItems = new Item("Test", null);
    }

    /** Testing Price.
     */
    @Test
    public void testItemStringBigDecimal() {
        myTwoItems = new Item("Test", BigDecimal.TEN);
        assertEquals("Testing Price", BigDecimal.TEN, myTwoItems.getPrice());
    }
    
    /** testing String for Null Pointer.
     */
    @Test(expected = NullPointerException.class)
    public void testItemStringBigDecimalIntBigDecimalStringNull() {
        myFourItems = new Item(null, BigDecimal.ONE, 0, BigDecimal.TEN);
    }
    
    /** Testing String for Illegal Argument.
     */
    @Test(expected = IllegalArgumentException.class)
    public void testItemStringBigDecimalIntBigDecimalStringIE() {
        myFourItems = new Item("", BigDecimal.ONE, 0, BigDecimal.TEN);
    }
    
    /** Testing price for Null Pointer.
     */
    @Test(expected = NullPointerException.class)
    public void testItemStringBigDecimalIntBigDecimalPriceNull() {
        myFourItems = new Item("Test", null, 0, BigDecimal.TEN);
    }

    /** Testing price less than 0.
     */
    @Test(expected = IllegalArgumentException.class)
    public void testItemStringBigDecimalIntBigDecimalPriceIE() {
        myFourItems = new Item("Test", BigDecimal.valueOf(-1), 0, BigDecimal.TEN);
    }
    
    /**Testing price equal zero.
     */
    @Test(expected = IllegalArgumentException.class)
    public void testItemStringBigDecimalIntBigDecimalPriceIEE() {
        myFourItems = new Item("Test", BigDecimal.valueOf(0), 0, BigDecimal.TEN);
    }
    
    /** Testing Price.
     */
    @Test
    public void testItemStringBigDecimalIntBigDecimalPrice() {
        myFourItems = new Item("Test", BigDecimal.ONE, 0, BigDecimal.TEN);
        assertEquals("Testing Price", BigDecimal.ONE, myFourItems.getPrice());
    }

    /** Testing quantity less than 0.
     */
    @Test(expected = IllegalArgumentException.class)
    public void testItemStringBigDecimalIntBigDecimalQuantityIE() {
        myFourItems = new Item("Test", BigDecimal.ONE, -1, BigDecimal.TEN);
    }
    
    /** Testing Bulk Quantity.
     */
    @Test
    public void testItemStringBigDecimalIntBigDecimalQuantity() {
        myFourItems = new Item("Test", BigDecimal.ONE, 12, BigDecimal.TEN);
        assertEquals("Testing Bulk Quantity", 12, myFourItems.getBulkQuantity());
    }
    
    /** Testing Bulk price for Null Pointer.
     */
    @Test(expected = NullPointerException.class)
    public void testItemStringBigDecimalIntBigDecimalBulkPriceNull() {
        myFourItems = new Item("Test", BigDecimal.TEN, 0, null);
    }
    
    /** Testing Bulk Price.
     */
    @Test
    public void testItemStringBigDecimalIntBigDecimalBulkPrice() {
        myFourItems = new Item("Test", BigDecimal.ONE, 0, BigDecimal.TEN);
        assertEquals("Testing Bulk Price", BigDecimal.TEN, myFourItems.getBulkPrice());
    }
    
    /** Testing Get price.
     */
    @Test
    public void testGetPrice() {
        assertEquals("Getting Price", BigDecimal.TEN, myFourItems.getPrice());
    }
    
    /** Testing Get bulk quantity.
     */
    @Test
    public void testGetBulkQuantity() {
        assertEquals("Getting Bulk Quantity", 4, myFourItems.getBulkQuantity());
    }

    /** Testing get Bulk Price.
     */
    @Test
    public void testGetBulkPrice() {
        assertEquals("Getting Bulk Price", BigDecimal.ONE, myFourItems.getBulkPrice());
    }

    /** Testing is bulk True.
     */
    @Test
    public void testIsBulkTrue() {
        assertEquals("Testing Is Bulk",  true, myFourItems.isBulk());
    }

    /** Testing is bulk False.
     */
    @Test
    public void testIsBulkFalse() {
        myFourItems = new Item("Test", BigDecimal.ONE, 0, BigDecimal.TEN);
        assertEquals("Testing Is Bulk",  false, myFourItems.isBulk());
    }
    
    /** Testing toString bulk
     */
    @Test
    public void testToStringBulk() {
       String expected = "Hello, $10 (4 for $1)";
       assertEquals("Testing String", expected, myFourItems.toString());
    }

    /** Testing toString if not bulk.
     */
    @Test
    public void testToString() {
       String expected = "Test, $1";
       myFourItems = new Item("Test", BigDecimal.ONE, 0, BigDecimal.TEN);
       assertEquals("Testing String", expected, myFourItems.toString());
    }

    /** Checking equals null.
     */
    @Test
    public void testEqualsObjectNull() {
        myFourItems.equals(null);
    }
    
    /** Checking two diff objects.
     */
    @Test
    public void testEqualsObjectDiff() {
        myFourItems.equals(myTwoItems);
    }

    /** Testing if class objects are the same.
     */
    @Test
    public void testEqualsObjectClass() {
        assertFalse(myFourItems.equals(BigDecimal.ONE));
    }
    
    /** Testing if toString is equal.
     */
    @Test
    public void testEqualsObjectString() {
        Item myTestItems = new Item("Test", BigDecimal.TEN, 4, BigDecimal.ONE);
        myFourItems.equals(myTestItems);
    }

    /**Checking if price is the same
     */
    @Test
    public void testEqualsObjectPrice() {
        Item myTestItems = new Item("Hello", BigDecimal.ONE, 4, BigDecimal.ONE);
        myFourItems.equals(myTestItems);
    }

    /** Checking if bulk quantity is the same
     */
    @Test
    public void testEqualsObjectQuantity() {
        Item myTestItems = new Item("Hello", BigDecimal.TEN, 2, BigDecimal.ONE);
        myFourItems.equals(myTestItems);
    }

    /** testing if Bulk price is the same.
     */
    @Test
    public void testEqualsObjectBulkPrice() {
        Item myTestItems = new Item("Hello", BigDecimal.TEN, 4, BigDecimal.TEN);
        myFourItems.equals(myTestItems);
    }

    /** Testing if same objects are equal.
     */
    @Test
    public void testEqualsObjectBulkSame() {
        myFourItems.equals(myFourItems);
    }

}
